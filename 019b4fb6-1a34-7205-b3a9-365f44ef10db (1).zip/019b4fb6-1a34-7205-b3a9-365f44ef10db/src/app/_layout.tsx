import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { Stack, useRouter, useSegments, useRootNavigationState } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { useColorScheme } from '@/lib/useColorScheme';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { KeyboardProvider } from 'react-native-keyboard-controller';
import { AuthProvider, useAuth } from '@/lib/auth-context';
import { useEffect, useState } from 'react';
import { isSupabaseConfigured } from '@/lib/supabase';
import { useAuthStore } from '@/lib/auth-store';

export const unstable_settings = {
  initialRouteName: 'signup',
};

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: 2,
    },
  },
});

function AuthRedirect() {
  const supabaseAuth = useAuth();
  const zustandAuth = useAuthStore((s) => s.isAuthenticated);
  const segments = useSegments();
  const router = useRouter();
  const navigationState = useRootNavigationState();
  const [isNavigationReady, setIsNavigationReady] = useState(false);

  // Use Supabase auth if configured, otherwise fall back to Zustand mock auth
  const isAuthenticated = isSupabaseConfigured()
    ? supabaseAuth.isAuthenticated
    : zustandAuth;
  const isLoading = isSupabaseConfigured()
    ? supabaseAuth.isLoading
    : false;

  // Wait for navigation to be fully mounted before allowing redirects
  useEffect(() => {
    if (navigationState?.key) {
      // Add a small delay to ensure router is fully ready
      const timer = setTimeout(() => {
        setIsNavigationReady(true);
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [navigationState?.key]);

  useEffect(() => {
    // Wait for navigation to be ready
    if (!isNavigationReady) return;

    // Wait for auth loading to complete
    if (isLoading) return;

    const inAuthGroup = segments[0] === 'login' || segments[0] === 'signup';

    if (!isAuthenticated && !inAuthGroup) {
      router.replace('/signup');
    } else if (isAuthenticated && inAuthGroup) {
      router.replace('/(tabs)');
    }
  }, [isAuthenticated, segments, isNavigationReady, isLoading, router]);

  return null;
}

function RootLayoutNav({ colorScheme }: { colorScheme: 'light' | 'dark' | null | undefined }) {
  return (
    <ThemeProvider value={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
      <Stack>
        <Stack.Screen name="signup" options={{ headerShown: false }} />
        <Stack.Screen name="login" options={{ headerShown: false }} />
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="bill/[id]" options={{ headerShown: false }} />
        <Stack.Screen name="executive-order/[id]" options={{ headerShown: false }} />
        <Stack.Screen name="scotus/[id]" options={{ headerShown: false }} />
        <Stack.Screen name="delegates" options={{ headerShown: false }} />
        <Stack.Screen name="messages" options={{ headerShown: false }} />
        <Stack.Screen name="conversation/[id]" options={{ headerShown: false }} />
        <Stack.Screen name="bill-of-rights" options={{ headerShown: false }} />
        <Stack.Screen name="constitution" options={{ headerShown: false }} />
        <Stack.Screen name="article-v" options={{ headerShown: false }} />
        <Stack.Screen name="modal" options={{ presentation: 'modal' }} />
      </Stack>
      <AuthRedirect />
    </ThemeProvider>
  );
}

export default function RootLayout() {
  const colorScheme = useColorScheme();

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <GestureHandlerRootView style={{ flex: 1 }}>
          <KeyboardProvider>
            <StatusBar style={colorScheme === 'dark' ? 'light' : 'dark'} />
            <RootLayoutNav colorScheme={colorScheme} />
          </KeyboardProvider>
        </GestureHandlerRootView>
      </AuthProvider>
    </QueryClientProvider>
  );
}
