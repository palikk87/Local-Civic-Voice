import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { Vote, Eye, EyeOff, Mail, Lock, ArrowRight } from 'lucide-react-native';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';
import { useAuth } from '@/lib/auth-context';
import { useAuthStore } from '@/lib/auth-store';
import { isSupabaseConfigured } from '@/lib/supabase';

export default function LoginScreen() {
  const router = useRouter();

  // Use Supabase auth if configured, otherwise fall back to mock auth
  const supabaseAuth = useAuth();
  const mockSignIn = useAuthStore((s) => s.signIn);
  const mockIsLoading = useAuthStore((s) => s.isLoading);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [resetEmailSent, setResetEmailSent] = useState(false);

  const isLoading = isSupabaseConfigured() ? isSubmitting : mockIsLoading;

  const handleSignIn = async () => {
    setError('');

    if (!email.trim()) {
      setError('Please enter your email');
      return;
    }
    if (!password) {
      setError('Please enter your password');
      return;
    }

    const cleanEmail = email.toLowerCase().trim();

    if (isSupabaseConfigured()) {
      setIsSubmitting(true);
      try {
        const { error: authError } = await supabaseAuth.signIn(cleanEmail, password);

        if (authError) {
          setError(authError.message);
        }
      } finally {
        setIsSubmitting(false);
      }
    } else {
      // Fall back to mock auth
      const result = await mockSignIn(cleanEmail, password);
      if (!result.success) {
        setError(result.error ?? 'Something went wrong');
      }
    }
  };

  const handleForgotPassword = async () => {
    if (!email.trim()) {
      setError('Please enter your email to reset password');
      return;
    }

    if (isSupabaseConfigured()) {
      setIsSubmitting(true);
      try {
        const { error: resetError } = await supabaseAuth.resetPassword(email.toLowerCase().trim());
        if (resetError) {
          setError(resetError.message);
        } else {
          setResetEmailSent(true);
          setError('');
        }
      } finally {
        setIsSubmitting(false);
      }
    } else {
      setError('Password reset is not available in demo mode');
    }
  };

  return (
    <View className="flex-1 bg-slate-900">
      <LinearGradient
        colors={['#0F172A', '#1E3A5F', '#0F172A']}
        style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
      />

      <SafeAreaView className="flex-1">
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          className="flex-1"
        >
          <ScrollView
            className="flex-1"
            contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 24 }}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            {/* Logo & Header */}
            <Animated.View entering={FadeInUp.delay(100).springify()} className="items-center mb-10">
              <View className="w-24 h-24 rounded-full bg-amber-500/20 items-center justify-center mb-6">
                <Vote size={48} color="#F59E0B" />
              </View>
              <Text className="text-3xl font-bold text-white">Welcome Back</Text>
              <Text className="text-slate-400 mt-2 text-center">
                Sign in to continue making your voice heard
              </Text>
            </Animated.View>

            {/* Form */}
            <Animated.View entering={FadeInDown.delay(200).springify()}>
              {/* Email */}
              <View className="mb-4">
                <Text className="text-slate-300 font-medium mb-2">Email</Text>
                <View className="flex-row items-center bg-slate-800/60 border border-slate-700 rounded-xl px-4">
                  <Mail size={20} color="#64748B" />
                  <TextInput
                    className="flex-1 py-4 px-3 text-white text-base"
                    placeholder="john@example.com"
                    placeholderTextColor="#64748B"
                    value={email}
                    onChangeText={setEmail}
                    keyboardType="email-address"
                    autoCapitalize="none"
                    autoCorrect={false}
                  />
                </View>
              </View>

              {/* Password */}
              <View className="mb-4">
                <Text className="text-slate-300 font-medium mb-2">Password</Text>
                <View className="flex-row items-center bg-slate-800/60 border border-slate-700 rounded-xl px-4">
                  <Lock size={20} color="#64748B" />
                  <TextInput
                    className="flex-1 py-4 px-3 text-white text-base"
                    placeholder="Enter your password"
                    placeholderTextColor="#64748B"
                    value={password}
                    onChangeText={setPassword}
                    secureTextEntry={!showPassword}
                  />
                  <Pressable onPress={() => setShowPassword(!showPassword)}>
                    {showPassword ? (
                      <EyeOff size={20} color="#64748B" />
                    ) : (
                      <Eye size={20} color="#64748B" />
                    )}
                  </Pressable>
                </View>
              </View>

              {/* Forgot Password */}
              <Pressable
                onPress={() => setShowForgotPassword(!showForgotPassword)}
                className="mb-4"
              >
                <Text className="text-amber-500 text-right text-sm">Forgot password?</Text>
              </Pressable>

              {/* Forgot Password Form */}
              {showForgotPassword && (
                <Animated.View entering={FadeInDown.springify()} className="mb-4 p-4 bg-slate-800/60 rounded-xl border border-slate-700">
                  {resetEmailSent ? (
                    <Text className="text-emerald-400 text-center">
                      Password reset email sent! Check your inbox.
                    </Text>
                  ) : (
                    <>
                      <Text className="text-slate-300 text-sm mb-3">
                        Enter your email above and click below to receive a password reset link.
                      </Text>
                      <Pressable
                        onPress={handleForgotPassword}
                        disabled={isLoading}
                        className="bg-slate-700 rounded-lg py-3"
                      >
                        {isLoading ? (
                          <ActivityIndicator color="#F59E0B" />
                        ) : (
                          <Text className="text-amber-500 text-center font-semibold">
                            Send Reset Link
                          </Text>
                        )}
                      </Pressable>
                    </>
                  )}
                </Animated.View>
              )}

              {/* Error */}
              {error ? (
                <Animated.View entering={FadeInDown.springify()} className="mb-4">
                  <Text className="text-red-400 text-center">{error}</Text>
                </Animated.View>
              ) : null}

              {/* Sign In Button */}
              <Pressable
                onPress={handleSignIn}
                disabled={isLoading}
                className="bg-amber-500 rounded-xl py-4 flex-row items-center justify-center mb-6"
                style={{ opacity: isLoading ? 0.7 : 1 }}
              >
                {isLoading ? (
                  <ActivityIndicator color="#0F172A" />
                ) : (
                  <>
                    <Text className="text-slate-900 font-bold text-lg mr-2">Sign In</Text>
                    <ArrowRight size={20} color="#0F172A" />
                  </>
                )}
              </Pressable>

              {/* Sign Up Link */}
              <View className="flex-row justify-center">
                <Text className="text-slate-400">Don't have an account? </Text>
                <Pressable onPress={() => router.push('/signup')}>
                  <Text className="text-amber-500 font-semibold">Sign Up</Text>
                </Pressable>
              </View>
            </Animated.View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}
