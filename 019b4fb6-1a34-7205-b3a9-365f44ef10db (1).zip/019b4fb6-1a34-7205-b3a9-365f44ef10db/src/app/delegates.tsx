import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  Pressable,
  Image,
  TextInput,
  FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter, Stack } from 'expo-router';
import {
  ArrowLeft,
  Search,
  Users,
  ChevronRight,
  Shield,
  TrendingUp,
  Sparkles,
  XCircle,
  AlertTriangle,
} from 'lucide-react-native';
import Animated, { FadeInDown, FadeIn } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import {
  useDelegationStore,
  selectActiveDelegationsCount,
  selectIsDelegatingTo,
  selectHasActiveDelegations,
  type DelegateProfile,
  type PolicyCategory,
} from '@/lib/delegation-store';
import { categoryLabels, categoryColors } from '@/lib/mock-data';
import { cn } from '@/lib/cn';
import { DelegationRightIndicator, ArticleBadge } from '@/components/BillOfRightsBadge';

const CATEGORY_LIST: PolicyCategory[] = [
  'healthcare',
  'education',
  'environment',
  'economy',
  'technology',
  'housing',
  'civil_rights',
  'immigration',
];

function DelegateCard({
  delegate,
  index,
  onSelect,
}: {
  delegate: DelegateProfile;
  index: number;
  onSelect: (delegate: DelegateProfile) => void;
}) {
  const isDelegatedTo = useDelegationStore(selectIsDelegatingTo(delegate.userId));

  return (
    <Animated.View
      entering={FadeInDown.delay(index * 80).springify()}
      className="mx-4 mb-3"
    >
      <Pressable
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          onSelect(delegate);
        }}
        className={cn(
          'bg-slate-800/80 rounded-2xl p-4 border',
          isDelegatedTo ? 'border-amber-500/50' : 'border-slate-700/50'
        )}
      >
        <View className="flex-row items-start">
          <Image
            source={{ uri: delegate.avatar }}
            className="w-14 h-14 rounded-full"
          />
          <View className="flex-1 ml-3">
            <View className="flex-row items-center">
              <Text className="text-white font-semibold text-lg">
                {delegate.displayName}
              </Text>
              {isDelegatedTo && (
                <View className="ml-2 bg-amber-500/20 px-2 py-0.5 rounded-full">
                  <Text className="text-amber-500 text-xs font-medium">
                    Your Delegate
                  </Text>
                </View>
              )}
            </View>
            <Text className="text-slate-400 text-sm">@{delegate.username}</Text>

            {/* Expertise Tags */}
            <View className="flex-row flex-wrap mt-2">
              {delegate.expertise.map(cat => (
                <View
                  key={cat}
                  className="mr-1.5 mb-1 px-2 py-0.5 rounded-full"
                  style={{ backgroundColor: `${categoryColors[cat]}30` }}
                >
                  <Text
                    style={{ color: categoryColors[cat] }}
                    className="text-xs font-medium"
                  >
                    {categoryLabels[cat]}
                  </Text>
                </View>
              ))}
            </View>
          </View>
          <ChevronRight size={20} color="#64748B" />
        </View>

        <Text className="text-slate-300 text-sm mt-3 leading-5" numberOfLines={2}>
          {delegate.bio}
        </Text>

        {/* Stats */}
        <View className="flex-row mt-3 pt-3 border-t border-slate-700/50">
          <View className="flex-1 flex-row items-center">
            <Users size={14} color="#64748B" />
            <Text className="text-slate-400 text-sm ml-1.5">
              {delegate.delegatorCount.toLocaleString()} delegators
            </Text>
          </View>
          <View className="flex-row items-center">
            <TrendingUp size={14} color="#22C55E" />
            <Text className="text-emerald-500 text-sm ml-1.5">
              {delegate.votingRecord.totalVotes} votes cast
            </Text>
          </View>
        </View>
      </Pressable>
    </Animated.View>
  );
}

function CategoryFilter({
  selected,
  onSelect,
}: {
  selected: PolicyCategory | null;
  onSelect: (cat: PolicyCategory | null) => void;
}) {
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      className="px-4 mb-4"
      style={{ flexGrow: 0 }}
    >
      <Pressable
        onPress={() => onSelect(null)}
        className={cn(
          'mr-2 px-4 py-2 rounded-full',
          selected === null ? 'bg-amber-500' : 'bg-slate-800'
        )}
      >
        <Text
          className={cn(
            'font-medium',
            selected === null ? 'text-slate-900' : 'text-slate-300'
          )}
        >
          All
        </Text>
      </Pressable>

      {CATEGORY_LIST.map(cat => (
        <Pressable
          key={cat}
          onPress={() => onSelect(cat)}
          className={cn(
            'mr-2 px-4 py-2 rounded-full',
            selected === cat ? 'bg-amber-500' : 'bg-slate-800'
          )}
        >
          <Text
            className={cn(
              'font-medium',
              selected === cat ? 'text-slate-900' : 'text-slate-300'
            )}
          >
            {categoryLabels[cat]}
          </Text>
        </Pressable>
      ))}
    </ScrollView>
  );
}

export default function DelegatesScreen() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<PolicyCategory | null>(null);
  const [showRevokeConfirm, setShowRevokeConfirm] = useState(false);
  const featuredDelegates = useDelegationStore(s => s.featuredDelegates);
  const createDelegation = useDelegationStore(s => s.createDelegation);
  const revokeAllDelegations = useDelegationStore(s => s.revokeAllDelegations);
  const activeDelegationsCount = useDelegationStore(selectActiveDelegationsCount);
  const hasActiveDelegations = useDelegationStore(selectHasActiveDelegations);

  const filteredDelegates = featuredDelegates.filter(delegate => {
    const matchesSearch =
      searchQuery === '' ||
      delegate.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      delegate.username.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      selectedCategory === null ||
      delegate.expertise.includes(selectedCategory);

    return matchesSearch && matchesCategory;
  });

  const handleSelectDelegate = useCallback((delegate: DelegateProfile) => {
    // For now, navigate to a detail view or show delegation options
    // In full implementation, this would open a modal to select categories
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

    // Create global delegation for demo
    createDelegation(delegate.userId, 'all');
  }, [createDelegation]);

  const handleRevokeAll = useCallback(() => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    revokeAllDelegations();
    setShowRevokeConfirm(false);
  }, [revokeAllDelegations]);

  const renderItem = useCallback(
    ({ item, index }: { item: DelegateProfile; index: number }) => (
      <DelegateCard
        delegate={item}
        index={index}
        onSelect={handleSelectDelegate}
      />
    ),
    [handleSelectDelegate]
  );

  const keyExtractor = useCallback((item: DelegateProfile) => item.userId, []);

  return (
    <>
      <Stack.Screen options={{ headerShown: false }} />
      <View className="flex-1 bg-slate-900">
        <LinearGradient
          colors={['#0F172A', '#1E293B', '#0F172A']}
          style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
        />

        <SafeAreaView edges={['top']} className="flex-1">
          {/* Header */}
          <View className="px-4 py-3 border-b border-slate-800">
            <View className="flex-row items-center">
              <Pressable
                onPress={() => router.back()}
                className="bg-slate-800 p-2 rounded-full mr-3"
              >
                <ArrowLeft size={20} color="#fff" />
              </Pressable>
              <View className="flex-1">
                <Text className="text-xl font-bold text-white">
                  Find Delegates
                </Text>
                <Text className="text-slate-400 text-sm">
                  Liquid Democracy • Delegate your vote
                </Text>
              </View>
            </View>
          </View>

          {/* Info Banner */}
          <View className="mx-4 mt-4 mb-2 p-4 bg-amber-900/20 rounded-xl border border-amber-700/30">
            <View className="flex-row items-start">
              <Sparkles size={20} color="#F59E0B" />
              <View className="flex-1 ml-3">
                <View className="flex-row items-center justify-between mb-1">
                  <Text className="text-amber-400 font-semibold">
                    What is Liquid Democracy?
                  </Text>
                  <ArticleBadge articleNumber="I" size="sm" />
                </View>
                <Text className="text-slate-300 text-sm leading-5">
                  Delegate your vote to trusted experts. They'll vote on your behalf
                  for topics you choose. You can revoke anytime.
                </Text>
              </View>
            </View>
          </View>

          {/* Article I Rights Indicator */}
          <View className="mx-4 mb-4">
            <DelegationRightIndicator canRevoke={true} />
          </View>

          {/* Revoke All Delegations - Article I Right */}
          {hasActiveDelegations && (
            <Animated.View entering={FadeIn.duration(300)} className="mx-4 mb-4">
              {!showRevokeConfirm ? (
                <Pressable
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                    setShowRevokeConfirm(true);
                  }}
                  className="bg-red-900/30 rounded-xl p-4 border border-red-700/40"
                >
                  <View className="flex-row items-center justify-between">
                    <View className="flex-row items-center flex-1">
                      <View className="w-10 h-10 rounded-full bg-red-500/20 items-center justify-center mr-3">
                        <XCircle size={20} color="#EF4444" />
                      </View>
                      <View className="flex-1">
                        <Text className="text-red-100 font-semibold">
                          Reclaim Your Voice
                        </Text>
                        <Text className="text-red-300/70 text-xs mt-0.5">
                          Revoke all delegations instantly
                        </Text>
                      </View>
                    </View>
                    <ArticleBadge articleNumber="I" size="sm" />
                  </View>
                </Pressable>
              ) : (
                <View className="bg-red-900/40 rounded-xl p-4 border border-red-500/50">
                  <View className="flex-row items-center mb-3">
                    <AlertTriangle size={20} color="#EF4444" />
                    <Text className="text-red-100 font-semibold ml-2">
                      Confirm Revocation
                    </Text>
                  </View>
                  <Text className="text-red-200/80 text-sm mb-4">
                    Per Article I of the Bill of Rights, you have the absolute right to revoke
                    all delegations instantly, without penalty. Your {activeDelegationsCount} active
                    delegation{activeDelegationsCount !== 1 ? 's' : ''} will be revoked.
                  </Text>
                  <View className="flex-row">
                    <Pressable
                      onPress={() => setShowRevokeConfirm(false)}
                      className="flex-1 bg-slate-700 rounded-lg py-3 mr-2 items-center"
                    >
                      <Text className="text-slate-300 font-medium">Cancel</Text>
                    </Pressable>
                    <Pressable
                      onPress={handleRevokeAll}
                      className="flex-1 bg-red-600 rounded-lg py-3 items-center"
                    >
                      <Text className="text-white font-semibold">Revoke All</Text>
                    </Pressable>
                  </View>
                </View>
              )}
            </Animated.View>
          )}

          {/* Active Delegations */}
          {activeDelegationsCount > 0 && (
            <View className="mx-4 mb-4 p-3 bg-slate-800/60 rounded-xl border border-slate-700/50">
              <View className="flex-row items-center mb-2">
                <Shield size={16} color="#22C55E" />
                <Text className="text-emerald-400 font-medium ml-2">
                  Active Delegations: {activeDelegationsCount}
                </Text>
              </View>
              <Text className="text-slate-400 text-sm">
                Your vote is being represented by trusted delegates
              </Text>
            </View>
          )}

          {/* Search */}
          <View className="px-4 mb-4">
            <View className="flex-row items-center bg-slate-800 rounded-xl px-4 py-3">
              <Search size={18} color="#64748B" />
              <TextInput
                value={searchQuery}
                onChangeText={setSearchQuery}
                placeholder="Search delegates..."
                placeholderTextColor="#64748B"
                className="flex-1 ml-3 text-white"
              />
            </View>
          </View>

          {/* Category Filter */}
          <CategoryFilter
            selected={selectedCategory}
            onSelect={setSelectedCategory}
          />

          {/* Delegates List */}
          <FlatList
            data={filteredDelegates}
            renderItem={renderItem}
            keyExtractor={keyExtractor}
            contentContainerStyle={{ paddingBottom: 20 }}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View className="items-center py-12">
                <Users size={48} color="#64748B" />
                <Text className="text-slate-400 text-lg mt-4">
                  No delegates found
                </Text>
                <Text className="text-slate-500 text-sm mt-1">
                  Try adjusting your filters
                </Text>
              </View>
            }
          />
        </SafeAreaView>
      </View>
    </>
  );
}
