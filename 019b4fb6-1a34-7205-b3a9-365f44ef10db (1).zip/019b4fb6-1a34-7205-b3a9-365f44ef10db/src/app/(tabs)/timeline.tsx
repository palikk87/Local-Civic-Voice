import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  Pressable,
  Image,
  FlatList,
  RefreshControl,
  Modal,
  Alert,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import {
  Plus,
  Heart,
  MessageCircle,
  Share2,
  Repeat2,
  Mail,
  MoreHorizontal,
  FileText,
  ExternalLink,
  ThumbsUp,
  ThumbsDown,
  UserPlus,
  UserCheck,
  Scale,
  Landmark,
  Gavel,
  TrendingUp,
  Globe,
  ChevronRight,
} from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import Animated, {
  FadeIn,
  FadeInDown,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import {
  useTimelineStore,
  selectPosts,
  selectUnreadCount,
  type TimelinePost,
  type ContentType,
} from '@/lib/timeline-store';
import {
  useGlobalEngagementStore,
  type ReferenceType,
} from '@/lib/global-engagement-store';
import { currentUser, mockBills } from '@/lib/mock-data';
import CreatePostModal from '@/components/CreatePostModal';
import ShareModal from '@/components/ShareModal';
import PostOptionsModal from '@/components/PostOptionsModal';
import CommentSection, { parseContentWithMentions } from '@/components/CommentSection';
import GlobalPulseDrawer from '@/components/GlobalPulseDrawer';
import { cn } from '@/lib/cn';

// Time ago helper
function getTimeAgo(dateString: string): string {
  const now = new Date();
  const date = new Date(dateString);
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

  if (seconds < 60) return 'just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d`;
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

// Format large numbers
function formatCount(num: number): string {
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
  return num.toString();
}

// Map content types to reference types
function getRefTypeFromContentType(contentType: ContentType): ReferenceType | null {
  switch (contentType) {
    case 'bill':
      return 'bill';
    case 'executive_order':
      return 'executive_order';
    case 'scotus_case':
      return 'scotus_case';
    default:
      return null;
  }
}

// Content type icons and colors
const contentTypeConfig: Record<ContentType, { icon: 'landmark' | 'file' | 'scale'; color: string; label: string }> = {
  bill: { icon: 'landmark', color: '#3B82F6', label: 'Bill' },
  executive_order: { icon: 'file', color: '#F59E0B', label: 'Executive Order' },
  scotus_case: { icon: 'scale', color: '#8B5CF6', label: 'Court Case' },
  text: { icon: 'file', color: '#64748B', label: 'Post' },
};

// Branch labels and colors (matching Feed)
const branchLabels: Record<string, string> = {
  legislative: 'Congress',
  executive: 'Executive',
  judicial: 'Supreme Court',
};

const branchColors: Record<string, string> = {
  legislative: '#3B82F6',
  executive: '#F59E0B',
  judicial: '#8B5CF6',
};

// Category colors (matching Feed)
const categoryColors: Record<string, string> = {
  healthcare: '#EF4444',
  economy: '#22C55E',
  education: '#3B82F6',
  environment: '#10B981',
  defense: '#6366F1',
  immigration: '#F59E0B',
  infrastructure: '#8B5CF6',
  civil_rights: '#EC4899',
  technology: '#06B6D4',
  foreign_policy: '#F97316',
};

const categoryLabels: Record<string, string> = {
  healthcare: 'Healthcare',
  economy: 'Economy',
  education: 'Education',
  environment: 'Environment',
  defense: 'Defense',
  immigration: 'Immigration',
  infrastructure: 'Infrastructure',
  civil_rights: 'Civil Rights',
  technology: 'Technology',
  foreign_policy: 'Foreign Policy',
};

// Branch Badge Component (matching Feed)
function BranchBadge({ branch }: { branch?: string }) {
  const branchType = branch ?? 'legislative';
  const color = branchColors[branchType] ?? '#3B82F6';
  const label = branchLabels[branchType] ?? 'Congress';

  return (
    <View
      className="flex-row items-center px-2 py-0.5 rounded-full mr-2"
      style={{ backgroundColor: `${color}20` }}
    >
      {branchType === 'legislative' && <Landmark size={10} color={color} />}
      {branchType === 'executive' && <FileText size={10} color={color} />}
      {branchType === 'judicial' && <Scale size={10} color={color} />}
      <Text className="text-xs font-medium ml-1" style={{ color }}>
        {label}
      </Text>
    </View>
  );
}

// Single post component with full feature parity
function PostCard({
  post,
  index,
  onComment,
  onShare,
  onMore,
}: {
  post: TimelinePost;
  index: number;
  onComment: (post: TimelinePost) => void;
  onShare: (post: TimelinePost) => void;
  onMore: (post: TimelinePost) => void;
}) {
  const router = useRouter();
  const [briefExpanded, setBriefExpanded] = useState(false);
  const likePost = useTimelineStore((s) => s.likePost);
  const voteOnPost = useTimelineStore((s) => s.voteOnPost);
  const followAuthor = useTimelineStore((s) => s.followAuthor);
  const unfollowAuthor = useTimelineStore((s) => s.unfollowAuthor);

  // Global engagement - for posts with reference IDs
  const referenceId = post.sharedContent?.id;
  const refType = getRefTypeFromContentType(post.contentType);
  const globalEngagement = useGlobalEngagementStore((s) =>
    referenceId ? s.getGlobalEngagement(referenceId) : undefined
  );
  const globalUserVote = useGlobalEngagementStore((s) =>
    referenceId ? s.getUserVote(referenceId) : undefined
  );
  const voteOnReference = useGlobalEngagementStore((s) => s.voteOnReference);

  // Check if this is a library post (define early for use in handlers)
  const isLibraryPost = post.source === 'library';

  const likeScale = useSharedValue(1);
  const supportScale = useSharedValue(1);
  const opposeScale = useSharedValue(1);

  const likeAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: likeScale.value }],
  }));

  const supportAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: supportScale.value }],
  }));

  const opposeAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: opposeScale.value }],
  }));

  const handleLike = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    likeScale.value = withSpring(1.3, { damping: 4 }, () => {
      likeScale.value = withSpring(1);
    });
    likePost(post.id);
  };

  const handleSupport = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    supportScale.value = withSpring(1.2, { damping: 4 }, () => {
      supportScale.value = withSpring(1);
    });

    // Vote on both local post AND global reference
    voteOnPost(post.id, 'support');

    // Update global engagement if this post has a reference
    if (referenceId) {
      voteOnReference(referenceId, 'support', post.id, post.author.id);
    }
  };

  const handleOppose = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    opposeScale.value = withSpring(1.2, { damping: 4 }, () => {
      opposeScale.value = withSpring(1);
    });

    // Vote on both local post AND global reference
    voteOnPost(post.id, 'oppose');

    // Update global engagement if this post has a reference
    if (referenceId) {
      voteOnReference(referenceId, 'oppose', post.id, post.author.id);
    }
  };

  const handleFollow = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (post.author.isFollowing) {
      unfollowAuthor(post.author.id);
    } else {
      followAuthor(post.author.id);
    }
  };

  const handleViewContent = () => {
    // Navigate to internal detail pages for all posts (including library posts)
    if (post.sharedContent?.id) {
      switch (post.contentType) {
        case 'bill':
          router.push(`/bill/${post.sharedContent.id}`);
          break;
        case 'executive_order':
          router.push(`/executive-order/${post.sharedContent.id}`);
          break;
        case 'scotus_case':
          router.push(`/scotus/${post.sharedContent.id}`);
          break;
        default:
          router.push(`/bill/${post.sharedContent.id}`);
      }
    }
  };

  const timeAgo = getTimeAgo(post.createdAt);
  const isOwnPost = post.author.id === currentUser.id;
  const contentConfig = contentTypeConfig[post.contentType] ?? contentTypeConfig.text;

  // Get bill data if shared from mock
  const sharedBill = post.sharedContent?.type === 'bill'
    ? mockBills.find((b) => b.id === post.sharedContent?.id)
    : null;

  // Use global engagement counts if available, otherwise fall back to local
  const hasGlobalEngagement = globalEngagement !== undefined;
  const supportCount = hasGlobalEngagement ? globalEngagement.supportVotes : (post.voteCounts?.support ?? 0);
  const opposeCount = hasGlobalEngagement ? globalEngagement.opposeVotes : (post.voteCounts?.oppose ?? 0);
  const userVote = globalUserVote?.vote ?? post.voteCounts?.userVote;
  const hasVoteCounts = post.voteCounts !== undefined;

  return (
    <Animated.View
      entering={FadeInDown.delay(index * 50).springify()}
      className="mx-4 mb-4 bg-slate-800/60 rounded-2xl border border-slate-700/50 overflow-hidden"
    >
      {/* Library source indicator */}
      {isLibraryPost && (
        <View className="flex-row items-center justify-between px-4 pt-3 pb-1">
          <View className="flex-row items-center">
            <View
              className="w-2 h-2 rounded-full mr-2"
              style={{ backgroundColor: contentConfig.color }}
            />
            <Text style={{ color: contentConfig.color }} className="text-xs font-medium">
              {contentConfig.label} from Library
            </Text>
          </View>
          {post.sharedContent?.sourceUrl && (
            <Pressable
              onPress={() => Linking.openURL(post.sharedContent?.sourceUrl ?? '')}
              className="flex-row items-center"
            >
              <ExternalLink size={12} color="#64748B" />
              <Text className="text-slate-500 text-xs ml-1">Source</Text>
            </Pressable>
          )}
        </View>
      )}

      {/* Repost indicator (for non-library shares) */}
      {!isLibraryPost && post.type === 'share' && post.sharedContent?.originalAuthor && (
        <View className="flex-row items-center px-4 pt-3 pb-1">
          <Repeat2 size={14} color="#64748B" />
          <Text className="text-slate-500 text-xs ml-2">
            {post.author.displayName} shared
          </Text>
        </View>
      )}

      {/* Author header with Follow button */}
      <View className="flex-row items-center p-4 pb-2">
        <Image
          source={{ uri: post.author.avatar }}
          className="w-12 h-12 rounded-full"
        />
        <View className="flex-1 ml-3">
          <View className="flex-row items-center">
            <Text className="text-white font-semibold">
              {post.author.displayName}
            </Text>
            <Text className="text-slate-500 text-sm ml-2">· {timeAgo}</Text>
          </View>
          <Text className="text-slate-400 text-sm">@{post.author.username}</Text>
        </View>

        {/* Follow button - show for other users' posts */}
        {!isOwnPost && (
          <Pressable
            onPress={handleFollow}
            className={cn(
              'flex-row items-center px-3 py-1.5 rounded-full mr-2',
              post.author.isFollowing ? 'bg-slate-700' : 'bg-amber-500'
            )}
          >
            {post.author.isFollowing ? (
              <>
                <UserCheck size={14} color="#94A3B8" />
                <Text className="text-slate-300 text-xs ml-1">Following</Text>
              </>
            ) : (
              <>
                <UserPlus size={14} color="#000" />
                <Text className="text-slate-900 text-xs font-medium ml-1">Follow</Text>
              </>
            )}
          </Pressable>
        )}

        <Pressable onPress={() => onMore(post)} className="p-2">
          <MoreHorizontal size={20} color="#64748B" />
        </Pressable>
      </View>

      {/* Content */}
      <View className="px-4">
        {/* AI Brief (for library posts) - Compact with expand option */}
        {post.aiBrief && (
          <Pressable
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              setBriefExpanded(!briefExpanded);
            }}
            className="bg-slate-700/40 rounded-lg p-3 mb-3 border-l-2 border-amber-500"
          >
            <View className="flex-row items-center justify-between mb-1">
              <Text className="text-amber-500 text-xs font-medium">CITIZEN'S BRIEF</Text>
              {!briefExpanded && post.aiBrief.length > 150 && (
                <Text className="text-amber-500/70 text-xs">Tap to expand</Text>
              )}
            </View>
            <Text
              className="text-white text-base leading-relaxed"
              numberOfLines={briefExpanded ? undefined : 3}
            >
              {post.aiBrief}
            </Text>
            {!briefExpanded && post.aiBrief.length > 150 && (
              <Text className="text-amber-500 text-sm mt-1 font-medium">Read more</Text>
            )}
            {briefExpanded && post.aiBrief.length > 150 && (
              <Text className="text-slate-400 text-sm mt-1">Show less</Text>
            )}
          </Pressable>
        )}

        {/* User's opinion on shared content */}
        {post.opinion && !post.aiBrief && (
          <Text className="text-white text-base mb-3 leading-relaxed">
            {post.opinion}
          </Text>
        )}

        {/* Original text post */}
        {post.type === 'original' && post.content && !post.aiBrief && (
          <Text className="text-white text-base mb-3 leading-relaxed">
            {post.content}
          </Text>
        )}

        {/* Shared content preview - Library post (matching Feed style) */}
        {isLibraryPost && post.sharedContent && (
          <View className="bg-slate-900/60 rounded-xl p-3 border border-slate-700/30 mb-3">
            {/* Branch and Category Badges Row */}
            <View className="flex-row items-center flex-wrap mb-2">
              {/* Branch Badge */}
              <BranchBadge branch={post.contentType === 'bill' ? 'legislative' : post.contentType === 'executive_order' ? 'executive' : post.contentType === 'scotus_case' ? 'judicial' : 'legislative'} />

              {/* Category Badge */}
              {post.sharedContent.category && (
                <View
                  className="px-2 py-0.5 rounded-full mr-2"
                  style={{ backgroundColor: `${categoryColors[post.sharedContent.category] ?? '#64748B'}30` }}
                >
                  <Text
                    style={{ color: categoryColors[post.sharedContent.category] ?? '#64748B' }}
                    className="text-xs font-medium"
                  >
                    {categoryLabels[post.sharedContent.category] ?? post.sharedContent.category.replace('_', ' ')}
                  </Text>
                </View>
              )}
            </View>

            {/* Title */}
            <Text className="text-white font-semibold text-base mb-1" numberOfLines={2}>
              {post.sharedContent.title}
            </Text>

            {/* Vote Progress Bar (matching Feed style) */}
            {(hasVoteCounts || hasGlobalEngagement) && (
              <View className="mt-3">
                <View className="flex-row items-center justify-between mb-2">
                  <Text className="text-xs text-slate-400">
                    {formatCount(supportCount + opposeCount)} community votes
                  </Text>
                  <Pressable onPress={handleViewContent} className="flex-row items-center">
                    <Text className="text-xs text-amber-500 mr-1">See details</Text>
                    <ChevronRight size={12} color="#F59E0B" />
                  </Pressable>
                </View>

                {/* Vote Progress Bar */}
                <View className="h-2 bg-slate-700 rounded-full overflow-hidden mb-3">
                  <View
                    className="h-full bg-emerald-500 rounded-l-full"
                    style={{ width: `${supportCount + opposeCount > 0 ? Math.round((supportCount / (supportCount + opposeCount)) * 100) : 50}%` }}
                  />
                </View>

                {/* Vote Buttons Row with Projected Outcome */}
                <View className="flex-row justify-between items-center">
                  <View className="flex-row items-center">
                    <Pressable
                      onPress={(e) => {
                        e.stopPropagation();
                        handleSupport();
                      }}
                      className={cn(
                        'flex-row items-center px-4 py-2 rounded-full mr-2',
                        userVote === 'support' ? 'bg-emerald-600' : 'bg-slate-700'
                      )}
                    >
                      <Animated.View style={supportAnimatedStyle}>
                        <ThumbsUp
                          size={16}
                          color={userVote === 'support' ? '#fff' : '#22C55E'}
                        />
                      </Animated.View>
                      <Text
                        className={cn(
                          'ml-2 font-semibold',
                          userVote === 'support' ? 'text-white' : 'text-emerald-500'
                        )}
                      >
                        Yea {supportCount + opposeCount > 0 ? Math.round((supportCount / (supportCount + opposeCount)) * 100) : 50}%
                      </Text>
                    </Pressable>

                    <Pressable
                      onPress={(e) => {
                        e.stopPropagation();
                        handleOppose();
                      }}
                      className={cn(
                        'flex-row items-center px-4 py-2 rounded-full',
                        userVote === 'oppose' ? 'bg-red-600' : 'bg-slate-700'
                      )}
                    >
                      <Animated.View style={opposeAnimatedStyle}>
                        <ThumbsDown
                          size={16}
                          color={userVote === 'oppose' ? '#fff' : '#EF4444'}
                        />
                      </Animated.View>
                      <Text
                        className={cn(
                          'ml-2 font-semibold',
                          userVote === 'oppose' ? 'text-white' : 'text-red-500'
                        )}
                      >
                        Nay {supportCount + opposeCount > 0 ? Math.round((opposeCount / (supportCount + opposeCount)) * 100) : 50}%
                      </Text>
                    </Pressable>
                  </View>

                  {/* Projected Outcome Badge */}
                  <View
                    className={cn(
                      'px-2 py-1 rounded-full',
                      supportCount > opposeCount
                        ? 'bg-emerald-900/50'
                        : opposeCount > supportCount
                        ? 'bg-red-900/50'
                        : 'bg-slate-700'
                    )}
                  >
                    <Text
                      className={cn(
                        'text-xs font-medium',
                        supportCount > opposeCount
                          ? 'text-emerald-400'
                          : opposeCount > supportCount
                          ? 'text-red-400'
                          : 'text-slate-400'
                      )}
                    >
                      {supportCount > opposeCount
                        ? 'Likely Pass'
                        : opposeCount > supportCount
                        ? 'Likely Fail'
                        : 'Uncertain'}
                    </Text>
                  </View>
                </View>
              </View>
            )}
          </View>
        )}

        {/* Shared content preview - Bill with full data (non-library, matching Feed style) */}
        {!isLibraryPost && post.sharedContent && sharedBill && (
          <View className="bg-slate-900/60 rounded-xl p-3 border border-slate-700/30 mb-3">
            {/* Branch and Category Badges Row */}
            <View className="flex-row items-start justify-between mb-2">
              <View className="flex-row items-center flex-wrap flex-1">
                {/* Branch Badge */}
                <BranchBadge branch={sharedBill.branch ?? 'legislative'} />

                {/* Category Badge */}
                {sharedBill.category && (
                  <View
                    className="px-2 py-0.5 rounded-full mr-2 mb-1"
                    style={{ backgroundColor: `${categoryColors[sharedBill.category] ?? '#64748B'}30` }}
                  >
                    <Text
                      style={{ color: categoryColors[sharedBill.category] ?? '#64748B' }}
                      className="text-xs font-medium"
                    >
                      {categoryLabels[sharedBill.category] ?? sharedBill.category}
                    </Text>
                  </View>
                )}

                {/* Chamber badge for legislative */}
                {(!sharedBill.branch || sharedBill.branch === 'legislative') && sharedBill.chamber && (
                  <View
                    className={cn(
                      'px-2 py-0.5 rounded-full mb-1',
                      sharedBill.chamber === 'house' ? 'bg-blue-900/50' : 'bg-purple-900/50'
                    )}
                  >
                    <Text
                      className={cn(
                        'text-xs font-medium',
                        sharedBill.chamber === 'house' ? 'text-blue-400' : 'text-purple-400'
                      )}
                    >
                      {sharedBill.chamber === 'house' ? 'House' : 'Senate'}
                    </Text>
                  </View>
                )}
              </View>
            </View>

            {/* Title */}
            <Text className="text-white font-semibold text-base mb-1">
              {sharedBill.shortTitle}
            </Text>
            <Text className="text-slate-400 text-sm" numberOfLines={2}>
              {sharedBill.title}
            </Text>

            {/* Vote Progress Bar (matching Feed) */}
            <View className="mt-3">
              <View className="flex-row items-center justify-between mb-2">
                <Text className="text-xs text-slate-400">
                  {sharedBill.communityVotes.totalVoters.toLocaleString()} community votes
                </Text>
                <Pressable onPress={handleViewContent} className="flex-row items-center">
                  <Text className="text-xs text-amber-500 mr-1">See details</Text>
                  <ChevronRight size={12} color="#F59E0B" />
                </Pressable>
              </View>

              {/* Vote Progress Bar */}
              <View className="h-2 bg-slate-700 rounded-full overflow-hidden mb-3">
                <View
                  className="h-full bg-emerald-500 rounded-l-full"
                  style={{ width: `${sharedBill.communityVotes.totalVoters > 0 ? Math.round((sharedBill.communityVotes.yea / sharedBill.communityVotes.totalVoters) * 100) : 50}%` }}
                />
              </View>

              {/* Vote Buttons Row with Projected Outcome */}
              <View className="flex-row justify-between items-center">
                <View className="flex-row items-center">
                  <Pressable
                    onPress={handleSupport}
                    className={cn(
                      'flex-row items-center px-4 py-2 rounded-full mr-2',
                      userVote === 'support' ? 'bg-emerald-600' : 'bg-slate-700'
                    )}
                  >
                    <Animated.View style={supportAnimatedStyle}>
                      <ThumbsUp
                        size={16}
                        color={userVote === 'support' ? '#fff' : '#22C55E'}
                      />
                    </Animated.View>
                    <Text
                      className={cn(
                        'ml-2 font-semibold',
                        userVote === 'support' ? 'text-white' : 'text-emerald-500'
                      )}
                    >
                      Yea {sharedBill.communityVotes.totalVoters > 0 ? Math.round((sharedBill.communityVotes.yea / sharedBill.communityVotes.totalVoters) * 100) : 50}%
                    </Text>
                  </Pressable>

                  <Pressable
                    onPress={handleOppose}
                    className={cn(
                      'flex-row items-center px-4 py-2 rounded-full',
                      userVote === 'oppose' ? 'bg-red-600' : 'bg-slate-700'
                    )}
                  >
                    <Animated.View style={opposeAnimatedStyle}>
                      <ThumbsDown
                        size={16}
                        color={userVote === 'oppose' ? '#fff' : '#EF4444'}
                      />
                    </Animated.View>
                    <Text
                      className={cn(
                        'ml-2 font-semibold',
                        userVote === 'oppose' ? 'text-white' : 'text-red-500'
                      )}
                    >
                      Nay {sharedBill.communityVotes.totalVoters > 0 ? Math.round((sharedBill.communityVotes.nay / sharedBill.communityVotes.totalVoters) * 100) : 50}%
                    </Text>
                  </Pressable>
                </View>

                {/* Projected Outcome Badge */}
                <View
                  className={cn(
                    'px-2 py-1 rounded-full',
                    sharedBill.projectedOutcome === 'likely_pass'
                      ? 'bg-emerald-900/50'
                      : sharedBill.projectedOutcome === 'likely_fail'
                      ? 'bg-red-900/50'
                      : 'bg-slate-700'
                  )}
                >
                  <Text
                    className={cn(
                      'text-xs font-medium',
                      sharedBill.projectedOutcome === 'likely_pass'
                        ? 'text-emerald-400'
                        : sharedBill.projectedOutcome === 'likely_fail'
                        ? 'text-red-400'
                        : 'text-slate-400'
                    )}
                  >
                    {sharedBill.projectedOutcome === 'likely_pass'
                      ? 'Likely Pass'
                      : sharedBill.projectedOutcome === 'likely_fail'
                      ? 'Likely Fail'
                      : 'Uncertain'}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        )}

        {/* Shared text post (no bill data, non-library) */}
        {!isLibraryPost && post.type === 'share' && post.sharedContent && !sharedBill && (
          <View className="bg-slate-700/60 rounded-xl p-4 border border-slate-600/50 mb-3">
            {post.sharedContent.originalAuthor && (
              <View className="flex-row items-center mb-2">
                <Image
                  source={{ uri: post.sharedContent.originalAuthor.avatar }}
                  className="w-6 h-6 rounded-full"
                />
                <Text className="text-slate-400 text-sm ml-2">
                  {post.sharedContent.originalAuthor.displayName}
                </Text>
                <Text className="text-slate-500 text-sm ml-1">
                  @{post.sharedContent.originalAuthor.username}
                </Text>
              </View>
            )}
            <Text className="text-white text-base leading-relaxed">
              {post.content || post.sharedContent.title}
            </Text>
          </View>
        )}
      </View>

      {/* Actions - matching Feed style */}
      <View className="flex-row items-center px-4 py-3 border-t border-slate-700/30">
        {/* Like */}
        <Pressable onPress={handleLike} className="flex-row items-center mr-6">
          <Animated.View style={likeAnimatedStyle}>
            <Heart
              size={18}
              color={post.isLiked ? '#EF4444' : '#64748B'}
              fill={post.isLiked ? '#EF4444' : 'transparent'}
            />
          </Animated.View>
          <Text className={cn('ml-1.5 text-sm', post.isLiked ? 'text-red-500' : 'text-slate-400')}>
            {post.likes > 0 ? post.likes : ''}
          </Text>
        </Pressable>

        {/* Reply */}
        <Pressable
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            onComment(post);
          }}
          className="flex-row items-center mr-6"
        >
          <MessageCircle size={18} color="#64748B" />
          <Text className="ml-1.5 text-slate-400 text-sm">Reply</Text>
        </Pressable>

        {/* Share */}
        <Pressable
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            onShare(post);
          }}
          className="flex-row items-center"
        >
          <Share2 size={18} color="#64748B" />
          <Text className="ml-1.5 text-slate-400 text-sm">Share</Text>
        </Pressable>
      </View>

      {/* Comments preview */}
      {post.comments.length > 0 && (
        <View className="px-4 pb-3 border-t border-slate-700/30 pt-3">
          {post.comments.slice(0, 2).map((comment) => (
            <View key={comment.id} className="flex-row mb-2">
              <Image source={{ uri: comment.author.avatar }} className="w-8 h-8 rounded-full" />
              <View className="flex-1 ml-2 bg-slate-700/40 rounded-xl rounded-tl-sm px-3 py-2">
                <Text className="text-white text-sm font-medium">{comment.author.displayName}</Text>
                {parseContentWithMentions(comment.content, comment.taggedUsers)}
              </View>
            </View>
          ))}
          {post.comments.length > 2 && (
            <Pressable onPress={() => onComment(post)}>
              <Text className="text-amber-500 text-sm font-medium">
                View all {post.comments.length} comments
              </Text>
            </Pressable>
          )}
        </View>
      )}
    </Animated.View>
  );
}

// Post detail modal with full comments
function PostDetailModal({
  post,
  visible,
  onClose,
}: {
  post: TimelinePost | null;
  visible: boolean;
  onClose: () => void;
}) {
  if (!post) return null;

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View className="flex-1 bg-slate-900">
        <LinearGradient
          colors={['#0F172A', '#1E293B', '#0F172A']}
          style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
        />

        <SafeAreaView edges={['top']} className="flex-1">
          {/* Header */}
          <View className="flex-row items-center justify-between px-4 py-3 border-b border-slate-800">
            <Pressable onPress={onClose}>
              <Text className="text-slate-400">Close</Text>
            </Pressable>
            <Text className="text-white font-semibold">Post</Text>
            <View className="w-12" />
          </View>

          {/* Post content */}
          <FlatList
            data={[post]}
            keyExtractor={(item) => item.id}
            renderItem={() => null}
            ListHeaderComponent={
              <PostCard
                post={post}
                index={0}
                onComment={() => {}}
                onShare={() => {}}
                onMore={() => {}}
              />
            }
            ListFooterComponent={
              <View className="border-t border-slate-800">
                <CommentSection postId={post.id} comments={post.comments} />
              </View>
            }
          />
        </SafeAreaView>
      </View>
    </Modal>
  );
}

export default function TimelineScreen() {
  const router = useRouter();
  const [refreshing, setRefreshing] = useState(false);
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showOptionsModal, setShowOptionsModal] = useState(false);
  const [selectedPost, setSelectedPost] = useState<TimelinePost | null>(null);
  const [showPostDetail, setShowPostDetail] = useState(false);
  const [showGlobalPulse, setShowGlobalPulse] = useState(false);

  const posts = useTimelineStore(selectPosts);
  const unreadMessages = useTimelineStore(selectUnreadCount);
  const refreshFeed = useTimelineStore((s) => s.refreshFeed);
  const deletePost = useTimelineStore((s) => s.deletePost);

  // Recalculate trending on mount
  const recalculateTrending = useGlobalEngagementStore((s) => s.recalculateTrendingScores);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    refreshFeed();
    recalculateTrending();
    setTimeout(() => setRefreshing(false), 1000);
  }, [refreshFeed, recalculateTrending]);

  const handleComment = (post: TimelinePost) => {
    setSelectedPost(post);
    setShowPostDetail(true);
  };

  const handleShare = (post: TimelinePost) => {
    setSelectedPost(post);
    setShowShareModal(true);
  };

  const handleMore = (post: TimelinePost) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelectedPost(post);
    setShowOptionsModal(true);
  };

  const handleDeletePost = (postId: string) => {
    Alert.alert(
      'Delete Post',
      'Are you sure you want to delete this post? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            deletePost(postId);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          },
        },
      ]
    );
  };

  const handleReportPost = (postId: string) => {
    Alert.alert(
      'Report Post',
      'Thank you for helping keep our community safe. This post has been reported for review.',
      [{ text: 'OK' }]
    );
  };

  const handleBlockUser = (userId: string) => {
    Alert.alert(
      'Block User',
      'You will no longer see posts from this user. They will not be notified.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Block',
          style: 'destructive',
          onPress: () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          },
        },
      ]
    );
  };

  const handleMuteUser = (userId: string) => {
    Alert.alert(
      'User Muted',
      'You will no longer see posts from this user in your feed.',
      [{ text: 'OK' }]
    );
  };

  const handleMessages = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push('/messages');
  };

  return (
    <View className="flex-1 bg-slate-900">
      <LinearGradient
        colors={['#0F172A', '#1E293B', '#0F172A']}
        style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
      />

      <SafeAreaView edges={['top']} className="flex-1">
        {/* Header */}
        <View className="flex-row items-center justify-between px-4 py-3">
          <Text className="text-2xl font-bold text-white">Timeline</Text>
          <View className="flex-row items-center">
            {/* Global Pulse */}
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setShowGlobalPulse(true);
              }}
              className="flex-row items-center bg-amber-500/20 px-3 py-2 rounded-full mr-2"
            >
              <TrendingUp size={16} color="#F59E0B" />
              <Text className="text-amber-500 text-xs font-medium ml-1">Pulse</Text>
            </Pressable>

            {/* Messages */}
            <Pressable
              onPress={handleMessages}
              className="w-10 h-10 rounded-full bg-slate-800 items-center justify-center mr-2 relative"
            >
              <Mail size={20} color="#94A3B8" />
              {unreadMessages > 0 && (
                <View className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-amber-500 items-center justify-center">
                  <Text className="text-slate-900 text-xs font-bold">
                    {unreadMessages}
                  </Text>
                </View>
              )}
            </Pressable>

            {/* Create post */}
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setShowCreatePost(true);
              }}
              className="w-10 h-10 rounded-full bg-amber-500 items-center justify-center"
            >
              <Plus size={22} color="#0F172A" />
            </Pressable>
          </View>
        </View>

        {/* Feed */}
        <FlatList
          data={posts}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingTop: 8, paddingBottom: 20 }}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor="#F59E0B"
              colors={['#F59E0B']}
            />
          }
          renderItem={({ item, index }) => (
            <PostCard
              post={item}
              index={index}
              onComment={handleComment}
              onShare={handleShare}
              onMore={handleMore}
            />
          )}
          ListEmptyComponent={
            <View className="flex-1 items-center justify-center py-20">
              <View className="w-20 h-20 rounded-full bg-slate-800 items-center justify-center mb-4">
                <MessageCircle size={36} color="#64748B" />
              </View>
              <Text className="text-white font-semibold text-lg">
                No posts yet
              </Text>
              <Text className="text-slate-400 text-sm mt-1 text-center px-8">
                Be the first to share something with the community
              </Text>
              <Pressable
                onPress={() => setShowCreatePost(true)}
                className="mt-4 px-6 py-3 bg-amber-500 rounded-full"
              >
                <Text className="text-slate-900 font-semibold">
                  Create Post
                </Text>
              </Pressable>
            </View>
          }
        />
      </SafeAreaView>

      {/* Modals */}
      <CreatePostModal
        visible={showCreatePost}
        onClose={() => setShowCreatePost(false)}
      />

      <ShareModal
        visible={showShareModal}
        onClose={() => {
          setShowShareModal(false);
          setSelectedPost(null);
        }}
        post={selectedPost ?? undefined}
      />

      <PostOptionsModal
        visible={showOptionsModal}
        onClose={() => {
          setShowOptionsModal(false);
          setSelectedPost(null);
        }}
        post={selectedPost}
        onDelete={handleDeletePost}
        onShare={(post) => {
          setShowOptionsModal(false);
          setSelectedPost(post);
          setShowShareModal(true);
        }}
        onReport={handleReportPost}
        onBlock={handleBlockUser}
        onMute={handleMuteUser}
      />

      <PostDetailModal
        post={selectedPost}
        visible={showPostDetail}
        onClose={() => {
          setShowPostDetail(false);
          setSelectedPost(null);
        }}
      />

      {/* Global Pulse Drawer */}
      <GlobalPulseDrawer
        visible={showGlobalPulse}
        onClose={() => setShowGlobalPulse(false)}
      />
    </View>
  );
}
