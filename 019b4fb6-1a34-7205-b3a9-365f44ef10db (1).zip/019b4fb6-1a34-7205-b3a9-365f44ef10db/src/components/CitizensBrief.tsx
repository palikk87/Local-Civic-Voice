/**
 * CitizensBrief Component
 *
 * Displays the AI-generated "Citizen's Brief" - a simplified,
 * non-partisan summary of legislation in three sections:
 * - The Goal: What the bill does
 * - The Wallet: Fiscal impact
 * - The Debate: Arguments for and against
 */

import React, { useState } from 'react';
import { View, Text, Pressable, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  FadeIn,
  FadeInDown,
  useSharedValue,
  useAnimatedStyle,
  withSpring,
} from 'react-native-reanimated';
import { Target, Wallet, Scale, Sparkles, RefreshCw, ExternalLink } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';

import type { Bill, CitizensBrief as CitizensBriefType } from '@/lib/types';
import { generateCitizensBrief, getAIAvailability } from '@/lib/ai-service';

interface CitizensBriefProps {
  bill: Bill;
  onGenerateBrief?: (brief: CitizensBriefType) => void;
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export function CitizensBrief({ bill, onGenerateBrief }: CitizensBriefProps) {
  const [brief, setBrief] = useState<CitizensBriefType | null>(bill.citizensBrief ?? null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { gemini, openai } = getAIAvailability();
  const hasAI = gemini || openai;

  const buttonScale = useSharedValue(1);

  const buttonAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: buttonScale.value }],
  }));

  const handleGenerate = async () => {
    if (!hasAI) {
      setError('AI service not available');
      return;
    }

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setIsLoading(true);
    setError(null);

    const result = await generateCitizensBrief(bill);

    setIsLoading(false);

    if (result.success && result.data) {
      setBrief(result.data);
      onGenerateBrief?.(result.data);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } else {
      setError(result.error ?? 'Failed to generate brief');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
  };

  const handlePressIn = () => {
    buttonScale.value = withSpring(0.95, { damping: 15 });
  };

  const handlePressOut = () => {
    buttonScale.value = withSpring(1, { damping: 15 });
  };

  if (!brief && !isLoading) {
    return (
      <Animated.View entering={FadeIn.duration(300)}>
        <LinearGradient
          colors={['rgba(59, 130, 246, 0.1)', 'rgba(139, 92, 246, 0.1)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ borderRadius: 20, padding: 20 }}
        >
          <View className="items-center">
            <View className="w-16 h-16 rounded-full bg-blue-500/20 items-center justify-center mb-4">
              <Sparkles size={32} color="#3B82F6" />
            </View>
            <Text className="text-white text-lg font-bold text-center mb-2">
              Citizen's Brief
            </Text>
            <Text className="text-gray-400 text-sm text-center mb-6 px-4">
              Get an AI-powered, non-partisan summary of this bill in plain English
            </Text>

            {error && (
              <Text className="text-red-400 text-sm text-center mb-4">
                {error}
              </Text>
            )}

            <AnimatedPressable
              onPress={handleGenerate}
              onPressIn={handlePressIn}
              onPressOut={handlePressOut}
              style={buttonAnimatedStyle}
              disabled={!hasAI}
              className="w-full"
            >
              <LinearGradient
                colors={hasAI ? ['#3B82F6', '#8B5CF6'] : ['#4B5563', '#374151']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={{
                  borderRadius: 12,
                  paddingVertical: 14,
                  paddingHorizontal: 24,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 8,
                }}
              >
                <Sparkles size={20} color="#FFFFFF" />
                <Text className="text-white font-bold text-base">
                  {hasAI ? 'Generate Brief' : 'AI Not Configured'}
                </Text>
              </LinearGradient>
            </AnimatedPressable>

            {!hasAI && (
              <Text className="text-gray-500 text-xs text-center mt-3">
                Add OpenAI or Google API key in ENV tab to enable
              </Text>
            )}
          </View>
        </LinearGradient>
      </Animated.View>
    );
  }

  if (isLoading) {
    return (
      <Animated.View entering={FadeIn.duration(300)}>
        <LinearGradient
          colors={['rgba(59, 130, 246, 0.1)', 'rgba(139, 92, 246, 0.1)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ borderRadius: 20, padding: 32 }}
        >
          <View className="items-center">
            <ActivityIndicator size="large" color="#3B82F6" />
            <Text className="text-white text-base font-semibold mt-4">
              Analyzing legislation...
            </Text>
            <Text className="text-gray-400 text-sm mt-2 text-center">
              Creating your Citizen's Brief
            </Text>
          </View>
        </LinearGradient>
      </Animated.View>
    );
  }

  return (
    <Animated.View entering={FadeIn.duration(400)}>
      <View className="rounded-3xl overflow-hidden">
        <LinearGradient
          colors={['rgba(24, 24, 27, 0.95)', 'rgba(39, 39, 42, 0.9)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ padding: 20 }}
        >
          {/* Header */}
          <View className="flex-row items-center justify-between mb-6">
            <View className="flex-row items-center gap-3">
              <View className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-500 items-center justify-center">
                <Sparkles size={20} color="#FFFFFF" />
              </View>
              <View>
                <Text className="text-white font-bold text-lg">Citizen's Brief</Text>
                <Text className="text-gray-400 text-xs">AI-Generated Summary</Text>
              </View>
            </View>
            <Pressable
              onPress={handleGenerate}
              className="p-2 rounded-lg bg-white/10"
            >
              <RefreshCw size={18} color="#9CA3AF" />
            </Pressable>
          </View>

          {/* The Goal */}
          <Animated.View
            entering={FadeInDown.delay(100).springify()}
            className="mb-5"
          >
            <View className="flex-row items-center gap-2 mb-3">
              <View className="w-8 h-8 rounded-lg bg-emerald-500/20 items-center justify-center">
                <Target size={18} color="#10B981" />
              </View>
              <Text className="text-emerald-400 font-bold text-sm uppercase tracking-wider">
                The Goal
              </Text>
            </View>
            <Text className="text-white text-base leading-relaxed pl-10">
              {brief?.theGoal}
            </Text>
          </Animated.View>

          {/* The Wallet */}
          <Animated.View
            entering={FadeInDown.delay(200).springify()}
            className="mb-5"
          >
            <View className="flex-row items-center gap-2 mb-3">
              <View className="w-8 h-8 rounded-lg bg-amber-500/20 items-center justify-center">
                <Wallet size={18} color="#F59E0B" />
              </View>
              <Text className="text-amber-400 font-bold text-sm uppercase tracking-wider">
                The Wallet
              </Text>
            </View>
            <Text className="text-white text-base leading-relaxed pl-10">
              {brief?.theWallet}
            </Text>
          </Animated.View>

          {/* The Debate */}
          <Animated.View
            entering={FadeInDown.delay(300).springify()}
            className="mb-4"
          >
            <View className="flex-row items-center gap-2 mb-3">
              <View className="w-8 h-8 rounded-lg bg-purple-500/20 items-center justify-center">
                <Scale size={18} color="#A78BFA" />
              </View>
              <Text className="text-purple-400 font-bold text-sm uppercase tracking-wider">
                The Debate
              </Text>
            </View>
            <Text className="text-white text-base leading-relaxed pl-10">
              {brief?.theDebate}
            </Text>
          </Animated.View>

          {/* Congress.gov link */}
          {bill.congressUrl && (
            <Pressable
              className="flex-row items-center justify-center gap-2 mt-4 py-3 rounded-xl bg-white/5"
            >
              <ExternalLink size={16} color="#6B7280" />
              <Text className="text-gray-400 text-sm">
                View full text on Congress.gov
              </Text>
            </Pressable>
          )}

          {/* Disclaimer */}
          <Text className="text-gray-500 text-xs text-center mt-4">
            AI-generated summary. Review official text for complete details.
          </Text>
        </LinearGradient>
      </View>
    </Animated.View>
  );
}
