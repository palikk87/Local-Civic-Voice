import React, { useState, useRef, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  Modal,
  Image,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { X, Send, AtSign, Image as ImageIcon } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import Animated, { FadeIn, FadeOut, SlideInDown } from 'react-native-reanimated';
import { useTimelineStore, type TaggedUser } from '@/lib/timeline-store';
import { sampleUsers, currentUser } from '@/lib/mock-data';
import type { User } from '@/lib/types';
import { cn } from '@/lib/cn';

interface CreatePostModalProps {
  visible: boolean;
  onClose: () => void;
  initialContent?: string;
  shareMode?: {
    type: 'bill' | 'post' | 'executive_order' | 'scotus_case';
    id: string;
    title: string;
  };
}

export default function CreatePostModal({
  visible,
  onClose,
  initialContent = '',
  shareMode,
}: CreatePostModalProps) {
  const [content, setContent] = useState(initialContent);
  const [showUserSuggestions, setShowUserSuggestions] = useState(false);
  const [userQuery, setUserQuery] = useState('');
  const [cursorPosition, setCursorPosition] = useState(0);
  const [isPosting, setIsPosting] = useState(false);
  const inputRef = useRef<TextInput>(null);

  const createPost = useTimelineStore((s) => s.createPost);
  const shareContent = useTimelineStore((s) => s.shareContent);
  const searchUsers = useTimelineStore((s) => s.searchUsers);

  const suggestedUsers = searchUsers(userQuery);

  const handleTextChange = useCallback((text: string) => {
    setContent(text);

    // Check for @ mentions
    const lastAtIndex = text.lastIndexOf('@', cursorPosition);
    if (lastAtIndex !== -1) {
      const textAfterAt = text.slice(lastAtIndex + 1, cursorPosition + 1);
      const hasSpace = textAfterAt.includes(' ');

      if (!hasSpace && textAfterAt.length > 0) {
        setUserQuery(textAfterAt);
        setShowUserSuggestions(true);
      } else if (textAfterAt.length === 0) {
        setUserQuery('');
        setShowUserSuggestions(true);
      } else {
        setShowUserSuggestions(false);
      }
    } else {
      setShowUserSuggestions(false);
    }
  }, [cursorPosition]);

  const handleSelectionChange = useCallback((event: { nativeEvent: { selection: { start: number; end: number } } }) => {
    setCursorPosition(event.nativeEvent.selection.start);
  }, []);

  const handleSelectUser = useCallback((user: User) => {
    const lastAtIndex = content.lastIndexOf('@', cursorPosition);
    if (lastAtIndex !== -1) {
      const beforeAt = content.slice(0, lastAtIndex);
      const afterCursor = content.slice(cursorPosition);
      const newContent = `${beforeAt}@${user.username} ${afterCursor}`;
      setContent(newContent);
    }
    setShowUserSuggestions(false);
    inputRef.current?.focus();
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }, [content, cursorPosition]);

  const handlePost = async () => {
    if (!content.trim() && !shareMode) return;

    setIsPosting(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    // Simulate posting delay
    await new Promise((resolve) => setTimeout(resolve, 500));

    if (shareMode) {
      shareContent(shareMode.type as 'bill' | 'executive_order' | 'scotus_case', shareMode.id, shareMode.title, content);
    } else {
      createPost(content);
    }

    setIsPosting(false);
    setContent('');
    onClose();
  };

  const handleClose = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setContent('');
    setShowUserSuggestions(false);
    onClose();
  };

  const canPost = content.trim().length > 0 || shareMode;

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={handleClose}
    >
      <View className="flex-1 bg-slate-900">
        <LinearGradient
          colors={['#0F172A', '#1E293B', '#0F172A']}
          style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
        />

        <SafeAreaView edges={['top']} className="flex-1">
          {/* Header */}
          <View className="flex-row items-center justify-between px-4 py-3 border-b border-slate-800">
            <Pressable
              onPress={handleClose}
              className="w-10 h-10 items-center justify-center"
            >
              <X size={24} color="#94A3B8" />
            </Pressable>

            <Text className="text-white font-semibold text-lg">
              {shareMode ? 'Share with Opinion' : 'Create Post'}
            </Text>

            <Pressable
              onPress={handlePost}
              disabled={!canPost || isPosting}
              className={cn(
                'px-4 py-2 rounded-full',
                canPost && !isPosting ? 'bg-amber-500' : 'bg-slate-700'
              )}
            >
              {isPosting ? (
                <ActivityIndicator size="small" color="#0F172A" />
              ) : (
                <Text
                  className={cn(
                    'font-semibold',
                    canPost ? 'text-slate-900' : 'text-slate-500'
                  )}
                >
                  Post
                </Text>
              )}
            </Pressable>
          </View>

          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            className="flex-1"
          >
            {/* Share Preview */}
            {shareMode && (
              <Animated.View
                entering={FadeIn}
                className="mx-4 mt-4 p-3 bg-slate-800/60 rounded-xl border border-slate-700/50"
              >
                <Text className="text-slate-400 text-xs mb-1">Sharing</Text>
                <Text className="text-white font-medium" numberOfLines={2}>
                  {shareMode.title}
                </Text>
                <View className="flex-row items-center mt-2">
                  <View className="px-2 py-0.5 rounded-full bg-amber-500/20">
                    <Text className="text-amber-400 text-xs font-medium">
                      {shareMode.type === 'bill' ? 'Bill' : shareMode.type === 'executive_order' ? 'Executive Order' : 'SCOTUS Case'}
                    </Text>
                  </View>
                </View>
              </Animated.View>
            )}

            {/* Author */}
            <View className="flex-row px-4 pt-4">
              <Image
                source={{ uri: currentUser.avatar }}
                className="w-12 h-12 rounded-full"
              />
              <View className="flex-1 ml-3">
                <Text className="text-white font-semibold">
                  {currentUser.displayName}
                </Text>
                <Text className="text-slate-400 text-sm">
                  @{currentUser.username}
                </Text>
              </View>
            </View>

            {/* Input */}
            <View className="flex-1 px-4 pt-4">
              <TextInput
                ref={inputRef}
                value={content}
                onChangeText={handleTextChange}
                onSelectionChange={handleSelectionChange}
                placeholder={shareMode ? "Add your thoughts..." : "What's on your mind?"}
                placeholderTextColor="#64748B"
                multiline
                autoFocus
                textAlignVertical="top"
                className="text-white text-lg flex-1"
                style={{ minHeight: 150 }}
              />

              {/* User Suggestions */}
              {showUserSuggestions && suggestedUsers.length > 0 && (
                <Animated.View
                  entering={SlideInDown.springify()}
                  exiting={FadeOut}
                  className="absolute top-0 left-0 right-0 bg-slate-800 rounded-xl border border-slate-700 overflow-hidden"
                  style={{ maxHeight: 200 }}
                >
                  <FlatList
                    data={suggestedUsers}
                    keyExtractor={(item) => item.id}
                    keyboardShouldPersistTaps="handled"
                    renderItem={({ item }) => (
                      <Pressable
                        onPress={() => handleSelectUser(item)}
                        className="flex-row items-center p-3 border-b border-slate-700/50"
                      >
                        <Image
                          source={{ uri: item.avatar }}
                          className="w-10 h-10 rounded-full"
                        />
                        <View className="ml-3">
                          <Text className="text-white font-medium">
                            {item.displayName}
                          </Text>
                          <Text className="text-slate-400 text-sm">
                            @{item.username}
                          </Text>
                        </View>
                      </Pressable>
                    )}
                  />
                </Animated.View>
              )}
            </View>

            {/* Bottom Actions */}
            <View className="flex-row items-center px-4 py-3 border-t border-slate-800">
              <Pressable
                onPress={() => {
                  const newContent = content + '@';
                  setContent(newContent);
                  setCursorPosition(newContent.length);
                  setShowUserSuggestions(true);
                  setUserQuery('');
                  inputRef.current?.focus();
                }}
                className="flex-row items-center p-2 rounded-lg bg-slate-800/60"
              >
                <AtSign size={20} color="#F59E0B" />
                <Text className="text-amber-500 text-sm ml-1 font-medium">
                  Mention
                </Text>
              </Pressable>

              <View className="flex-1" />

              <Text className="text-slate-500 text-sm">
                {content.length}/500
              </Text>
            </View>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </View>
    </Modal>
  );
}
