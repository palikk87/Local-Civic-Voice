// Bill and voting related types

// Government Branch identifier
export type GovernmentBranch = 'legislative' | 'executive' | 'judicial';

export interface Bill {
  id: string;
  title: string;
  shortTitle: string;
  status: 'introduced' | 'in_committee' | 'passed_house' | 'passed_senate' | 'enacted' | 'vetoed' | 'signed_into_law';
  chamber: 'house' | 'senate';
  sponsor: Representative;
  introducedDate: string;
  lastActionDate: string;
  category: BillCategory;
  congressNumber?: string; // e.g., "H.R.82", "S.596"
  congressUrl?: string; // Link to Congress.gov
  fullText: string;
  simplifiedText: string;
  realWorldImpact: string;
  relatedLaws: RelatedLaw[];
  communityVotes: VoteTally;
  projectedOutcome: 'likely_pass' | 'likely_fail' | 'uncertain' | 'unlikely_pass';
  officialVotes?: OfficialVoteTally;
  citizensBrief?: CitizensBrief; // AI-generated brief
  branch?: GovernmentBranch; // Default to 'legislative'
}

// Executive Order types
export interface ExecutiveOrder {
  id: string;
  eoNumber: string; // e.g., "EO 14147"
  title: string;
  shortTitle: string;
  president: string;
  signedDate: string;
  publishedDate: string;
  status: 'active' | 'revoked' | 'superseded' | 'expired' | 'partially_revoked';
  category: BillCategory;
  federalRegisterNumber?: string;
  federalRegisterUrl?: string;
  fullText: string;
  simplifiedText: string;
  realWorldImpact: string;
  communityVotes: VoteTally;
  relatedOrders?: string[]; // IDs of related EOs
  revokedBy?: string; // EO that revoked this one
  revokes?: string[]; // EOs this one revokes
  branch: 'executive';
}

// Supreme Court Case types
export interface SupremeCourtCase {
  id: string;
  docketNumber: string; // e.g., "22-451"
  caseName: string;
  shortName: string;
  term: string; // e.g., "2024"
  arguedDate?: string;
  decidedDate?: string;
  status: 'pending' | 'argued' | 'decided' | 'dismissed' | 'remanded';
  outcome?: 'affirmed' | 'reversed' | 'vacated' | 'remanded' | 'dismissed' | 'per_curiam';
  voteBreakdown?: {
    majority: number;
    dissent: number;
    concurring?: number;
  };
  category: BillCategory;
  lowerCourt: string;
  petitioner: string;
  respondent: string;
  questionPresented: string;
  simplifiedQuestion: string;
  majorityOpinion?: string;
  dissentOpinion?: string;
  realWorldImpact: string;
  communityVotes: VoteTally;
  justiceVotes?: JusticeVote[];
  courtListenerUrl?: string;
  branch: 'judicial';
}

export interface JusticeVote {
  justiceName: string;
  vote: 'majority' | 'dissent' | 'concurrence' | 'concur_in_part' | 'dissent_in_part';
  wroteOpinion: boolean;
}

export interface Justice {
  id: string;
  name: string;
  appointedBy: string;
  appointedYear: number;
  isChiefJustice: boolean;
  imageUrl: string;
  ideology: 'conservative' | 'liberal' | 'moderate';
}

// Union type for any government action
export type GovernmentAction = Bill | ExecutiveOrder | SupremeCourtCase;

// Helper to determine action type
export function isExecutiveOrder(action: GovernmentAction): action is ExecutiveOrder {
  return 'eoNumber' in action;
}

export function isSupremeCourtCase(action: GovernmentAction): action is SupremeCourtCase {
  return 'docketNumber' in action;
}

export function isBill(action: GovernmentAction): action is Bill {
  return 'chamber' in action && !('eoNumber' in action);
}

export type BillCategory =
  | 'healthcare'
  | 'education'
  | 'environment'
  | 'economy'
  | 'civil_rights'
  | 'defense'
  | 'immigration'
  | 'technology'
  | 'housing'
  | 'infrastructure';

export interface RelatedLaw {
  id: string;
  title: string;
  type: 'statutory' | 'case_law' | 'regulation' | 'constitutional';
  relationship: 'amends' | 'conflicts' | 'supports' | 'references';
  summary: string;
}

export interface VoteTally {
  yea: number;
  nay: number;
  totalVoters: number;
}

export interface OfficialVoteTally {
  yea: number;
  nay: number;
  abstain: number;
  notVoting: number;
}

export interface Representative {
  id: string;
  name: string;
  party: 'D' | 'R' | 'I';
  state: string;
  district?: string;
  chamber: 'house' | 'senate';
  imageUrl: string;
  contactEmail?: string;
  contactPhone?: string;
  website?: string;
  socialMedia?: {
    twitter?: string;
    facebook?: string;
  };
}

// Civil Leader engagement stats for author profiles
export interface CivicEngagementStats {
  libraryPostsCount: number;     // Posts shared from Library
  totalSupportVotes: number;     // Support votes received on posts
  totalOpposeVotes: number;      // Oppose votes received on posts
  totalRepGapVotes: number;      // Representation Gap poll votes received
  totalComments: number;         // Comments received on posts
  civilLeaderScore: number;      // Calculated engagement score
}

export interface User {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  bio?: string;
  location?: string;
  joinedDate: string;
  followers: number;
  following: number;
  votesCount: number;
  isFollowing?: boolean;
  // Civic engagement stats for "Civil Leader" growth
  civicStats?: CivicEngagementStats;
}

export interface FeedItem {
  id: string;
  type: 'vote' | 'comment' | 'share';
  user: User;
  bill: Bill;
  vote?: 'yea' | 'nay';
  comment?: string;
  timestamp: string;
  likes: number;
  isLiked?: boolean;
}

export interface UserVote {
  billId: string;
  vote: 'yea' | 'nay';
  votedAt: string;
}

// Representation Gap - measures discrepancy between public and official votes
export interface RepresentationGap {
  billId: string;
  billTitle: string;
  publicApprovalPct: number; // Civic Voice users' approval %
  officialApprovalPct: number; // Congress official vote %
  gapPercentage: number; // Absolute difference
  hasSignificantGap: boolean; // True if gap > 30%
  gapDirection: 'public_higher' | 'official_higher' | 'aligned';
}

// Citizen's Brief - AI-simplified bill summary
export interface CitizensBrief {
  theGoal: string; // What is this bill trying to do?
  theWallet: string; // How much taxpayer money does this cost or save?
  theDebate: string; // What are the two main arguments for and against?
}

// Congress.gov API response types
export interface CongressBill {
  billNumber: string;
  billType: 'hr' | 's' | 'hjres' | 'sjres';
  congress: number;
  title: string;
  latestAction: {
    actionDate: string;
    text: string;
  };
  originChamber: 'House' | 'Senate';
  updateDate: string;
  url: string;
  sponsors?: Array<{
    bioguideId: string;
    fullName: string;
    party: string;
    state: string;
    district?: number;
  }>;
}

// Foreign Aid tracking
export interface ForeignAidExpenditure {
  id: string;
  country: string;
  countryCode: string;
  fiscalYear: number;
  totalAmount: number;
  category: string;
  description: string;
  publicSentiment?: {
    approve: number;
    disapprove: number;
    totalVotes: number;
  };
}
