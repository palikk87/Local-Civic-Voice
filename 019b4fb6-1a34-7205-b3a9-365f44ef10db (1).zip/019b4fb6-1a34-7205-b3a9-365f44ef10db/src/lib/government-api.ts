// Government API Service - Live Gateway to Official Sources
// Routes queries to Congress.gov, Federal Register, and CourtListener APIs

import { supabase, isSupabaseConfigured } from './supabase';

// ===========================================
// API KEYS (Production)
// ===========================================
const API_KEYS = {
  congress: 'auhRbTAhurdkKqat6vgjKqLbPSXmdDqjqIY34j42',
  courtListener: '2c703c84f6b3c661484311163ce6759c368f3973',
  openai: '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',
  // Federal Register is open access - no key required
} as const;

// ===========================================
// TYPES
// ===========================================

export type SearchBranch = 'legislative' | 'executive' | 'judicial';

export interface GovernmentSearchResult {
  id: string;
  branch: SearchBranch;
  title: string;
  shortTitle: string;
  date: string;
  status: string;
  statusLabel: LegislativeStatus; // [Active], [Proposed], [Repealed], [Landmark], [Pending]
  category: string;
  sourceUrl: string;
  rawText: string;
  metadata: Record<string, unknown>;
}

// Congress.gov API Response Types
interface CongressBillResult {
  congress: number;
  type: string;
  number: number;
  title: string;
  originChamber: string;
  introducedDate: string;
  latestAction?: {
    actionDate: string;
    text: string;
  };
  policyArea?: {
    name: string;
  };
  url: string;
}

interface CongressSearchResponse {
  bills: CongressBillResult[];
  pagination: {
    count: number;
    next?: string;
  };
}

// Federal Register API Response Types
interface FederalRegisterResult {
  title: string;
  document_number: string;
  publication_date: string;
  type: string;
  subtype?: string;
  abstract?: string;
  raw_text_url?: string;
  html_url: string;
  pdf_url?: string;
  president?: { name: string };
  executive_order_number?: number;
  signing_date?: string;
  agencies?: { name: string }[];
}

interface FederalRegisterResponse {
  count: number;
  results: FederalRegisterResult[];
  next_page_url?: string;
}

// CourtListener API Response Types
interface CourtListenerResult {
  id: number;
  absolute_url: string;
  caseName: string;
  docketNumber: string;
  court: string;
  dateFiled?: string;
  dateArgued?: string;
  status?: string;
  snippet?: string;
  suitNature?: string;
}

interface CourtListenerResponse {
  count: number;
  results: CourtListenerResult[];
  next?: string;
}

// ===========================================
// CATEGORY MAPPING
// ===========================================

const mapPolicyAreaToCategory = (policyArea?: string): string => {
  if (!policyArea) return 'economy';

  const mapping: Record<string, string> = {
    'Health': 'healthcare',
    'Education': 'education',
    'Environmental Protection': 'environment',
    'Energy': 'environment',
    'Economics and Public Finance': 'economy',
    'Taxation': 'economy',
    'Commerce': 'economy',
    'Civil Rights and Liberties, Minority Issues': 'civil_rights',
    'Armed Forces and National Security': 'defense',
    'Immigration': 'immigration',
    'Science, Technology, Communications': 'technology',
    'Housing and Community Development': 'housing',
    'Transportation and Public Works': 'infrastructure',
  };

  return mapping[policyArea] ?? 'economy';
};

const mapExecutiveTypeToCategory = (type?: string, agencies?: string[]): string => {
  if (!type && !agencies) return 'economy';

  const agencyStr = agencies?.join(' ').toLowerCase() ?? '';

  if (agencyStr.includes('health') || agencyStr.includes('hhs')) return 'healthcare';
  if (agencyStr.includes('education')) return 'education';
  if (agencyStr.includes('epa') || agencyStr.includes('environment') || agencyStr.includes('energy')) return 'environment';
  if (agencyStr.includes('defense') || agencyStr.includes('military')) return 'defense';
  if (agencyStr.includes('homeland') || agencyStr.includes('immigration')) return 'immigration';
  if (agencyStr.includes('commerce') || agencyStr.includes('treasury')) return 'economy';
  if (agencyStr.includes('housing') || agencyStr.includes('hud')) return 'housing';
  if (agencyStr.includes('transport')) return 'infrastructure';

  return 'economy';
};

// ===========================================
// AI BILL IDENTIFIER GENERATION
// ===========================================

interface AIBillIdentifier {
  billNumber: string;      // e.g., "H.R. 2732", "S. 1234"
  friendlyName: string;    // e.g., "EARN IT Act", "TikTok Ban"
  congress: number;        // e.g., 118, 119
  relevanceNote: string;   // Why this bill is relevant to the search
}

// ===========================================
// STATUS LABELS (Perpetual Semantic Librarian)
// ===========================================

export type LegislativeStatus = 'active' | 'proposed' | 'repealed' | 'landmark' | 'pending';

/**
 * Determine status label based on latest action text
 * Labels results relative to the present state: [Active], [Proposed], [Repealed], [Landmark]
 */
function determineStatusLabel(latestAction?: string, status?: string): LegislativeStatus {
  const actionLower = (latestAction ?? '').toLowerCase();
  const statusLower = (status ?? '').toLowerCase();

  // Check for landmark indicators
  if (actionLower.includes('became public law') || actionLower.includes('signed by president')) {
    return 'landmark';
  }

  // Check for active/enacted
  if (actionLower.includes('enacted') || statusLower.includes('enacted') || statusLower.includes('law')) {
    return 'active';
  }

  // Check for repealed/vetoed
  if (actionLower.includes('vetoed') || actionLower.includes('repealed') || statusLower.includes('vetoed')) {
    return 'repealed';
  }

  // Check for proposed/introduced
  if (actionLower.includes('introduced') || actionLower.includes('referred to') || statusLower.includes('introduced')) {
    return 'proposed';
  }

  // Check for pending/in progress
  if (actionLower.includes('passed') || actionLower.includes('received') || actionLower.includes('committee')) {
    return 'pending';
  }

  return 'proposed';
}

/**
 * Use OpenAI to find congressional bills (Perpetual Semantic Librarian)
 * - Dynamic Time-Scoping: No fixed date filters, searches all archives
 * - Relevance over Recency: Semantic match priority with recency boost for modern vibes
 * - Modern Vibe detection: AI queries handle popularized names and modern terms
 */
async function getAIBillIdentifiers(query: string, limit = 15): Promise<AIBillIdentifier[]> {
  console.log(`OpenAI Search (Semantic Librarian): Finding bills for "${query}"`);

  const openaiKey = process.env.EXPO_PUBLIC_VIBECODE_OPENAI_API_KEY;

  if (!openaiKey) {
    console.log('OpenAI Search: No API key available');
    return [];
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: `# Role: Perpetual Semantic Librarian

# Search Protocol:
1. DYNAMIC TIME-SCOPING: Search ALL Congressional sessions (not just recent). If PATRIOT Act from 2001 matches the query, include it.
2. RELEVANCE OVER RECENCY: Prioritize semantic matches. If a 2015 law is THE primary match, rank it first.
3. MODERN VIBE DETECTION: For queries like "AI Privacy" or "TikTok Ban", apply recency boost but keep historical foundations visible.
4. EVOLUTIONARY CHAINS: If an old law is being debated/amended now, note both the original and current versions.

Return JSON array only: [{billNumber, friendlyName, congress, relevanceNote}]
- billNumber: Official designation (H.R. 1234, S. 567, etc.)
- friendlyName: Popular/colloquial name if known
- congress: Session number (107-119)
- relevanceNote: Why this matches the query, include [Landmark] for historic laws

Max ${limit} results. Sort by: relevance_weight: high. No date filters unless user specifies year.`
          },
          {
            role: 'user',
            content: query
          }
        ],
        max_tokens: 1500,
        temperature: 0.1,
      }),
    });

    if (!response.ok) {
      console.log('OpenAI Search: API request failed', response.status);
      return [];
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content ?? '[]';

    console.log('OpenAI raw response:', content.substring(0, 300));

    try {
      const jsonMatch = content.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]) as AIBillIdentifier[];
        console.log(`OpenAI Search: Found ${parsed.length} bills for "${query}"`);
        return parsed;
      }
    } catch {
      console.log('OpenAI Search: Failed to parse response');
    }

    return [];
  } catch (error) {
    console.log('OpenAI Search: Network error', error);
    return [];
  }
}

/**
 * Parse AI bill identifier into Congress.gov API format
 */
function parseBillIdentifier(identifier: AIBillIdentifier): { billType: string; billNumber: number; congress: number } | null {
  const billNum = identifier.billNumber.toUpperCase().trim();

  // Parse different formats like "H.R. 2732", "S. 1234", "H.Res. 100"
  const patterns = [
    { regex: /H\.?R\.?\s*(\d+)/i, type: 'hr' },
    { regex: /S\.?\s*(\d+)/i, type: 's' },
    { regex: /H\.?RES\.?\s*(\d+)/i, type: 'hres' },
    { regex: /S\.?RES\.?\s*(\d+)/i, type: 'sres' },
    { regex: /H\.?J\.?RES\.?\s*(\d+)/i, type: 'hjres' },
    { regex: /S\.?J\.?RES\.?\s*(\d+)/i, type: 'sjres' },
    { regex: /H\.?CON\.?RES\.?\s*(\d+)/i, type: 'hconres' },
    { regex: /S\.?CON\.?RES\.?\s*(\d+)/i, type: 'sconres' },
  ];

  for (const pattern of patterns) {
    const match = billNum.match(pattern.regex);
    if (match) {
      return {
        billType: pattern.type,
        billNumber: parseInt(match[1], 10),
        congress: identifier.congress,
      };
    }
  }

  return null;
}

/**
 * Fetch a specific bill from Congress.gov by its identifier
 */
async function fetchBillById(
  congress: number,
  billType: string,
  billNumber: number,
  friendlyName: string
): Promise<GovernmentSearchResult | null> {
  try {
    const url = `https://api.congress.gov/v3/bill/${congress}/${billType}/${billNumber}?api_key=${API_KEYS.congress}&format=json`;

    const response = await fetch(url, {
      headers: { 'Accept': 'application/json' },
    });

    if (!response.ok) {
      console.log(`Bill fetch failed: ${congress}/${billType}/${billNumber} - ${response.status}`);
      return null;
    }

    const data = await response.json();
    const bill = data.bill;

    if (!bill) return null;

    // Build public URL
    const chamberSlug = billType.startsWith('s') && billType !== 'sconres' && billType !== 'sres' && billType !== 'sjres' ? 'senate-bill' :
                        billType === 'hr' ? 'house-bill' :
                        billType === 'hres' ? 'house-resolution' :
                        billType === 'sres' ? 'senate-resolution' :
                        billType === 'hjres' ? 'house-joint-resolution' :
                        billType === 'sjres' ? 'senate-joint-resolution' :
                        billType === 'hconres' ? 'house-concurrent-resolution' :
                        billType === 'sconres' ? 'senate-concurrent-resolution' :
                        billType === 's' ? 'senate-bill' : 'house-bill';
    const publicUrl = `https://www.congress.gov/bill/${congress}th-congress/${chamberSlug}/${billNumber}`;

    const congressNumber = `${billType.toUpperCase()}.${billNumber}`;

    // Use friendly name as the display title if available
    const displayTitle = friendlyName || bill.title || 'Untitled Bill';
    const fullTitle = bill.title || 'Untitled Bill';

    return {
      id: `congress-${congress}-${congressNumber}-0`,
      branch: 'legislative',
      title: fullTitle,
      shortTitle: displayTitle.length > 80 ? `${displayTitle.slice(0, 80)}...` : displayTitle,
      date: bill.latestAction?.actionDate ?? bill.introducedDate ?? '',
      status: bill.latestAction?.text ?? 'Introduced',
      statusLabel: determineStatusLabel(bill.latestAction?.text),
      category: mapPolicyAreaToCategory(bill.policyArea?.name),
      sourceUrl: publicUrl,
      rawText: `${fullTitle}. ${bill.policyArea?.name ? `Policy Area: ${bill.policyArea.name}.` : ''} ${bill.originChamber ? `Originated in the ${bill.originChamber}.` : ''} ${bill.latestAction?.text ? `Latest action: ${bill.latestAction.text}` : ''}`.trim(),
      metadata: {
        congress: bill.congress,
        type: billType.toUpperCase(),
        number: billNumber,
        chamber: bill.originChamber,
        congressNumber,
        policyArea: bill.policyArea?.name,
        friendlyName,
      },
    };
  } catch (error) {
    console.log(`Error fetching bill ${congress}/${billType}/${billNumber}:`, error);
    return null;
  }
}

// ===========================================
// BILL CACHE FUNCTIONS (Cost Optimization)
// ===========================================

// Type for cached bill data (matches bill_cache table)
interface CachedBill {
  id: string;
  search_query: string | null;
  bill_id: string;
  congress: number;
  bill_type: string;
  bill_number: number;
  title: string;
  short_title: string;
  status: string;
  category: string;
  date: string;
  source_url: string;
  raw_text: string;
  metadata: Record<string, unknown>;
  created_at: string;
  expires_at: string;
}

/**
 * Check bill_cache for existing search results
 * Returns cached results if found and not expired
 */
async function getCachedSearchResults(query: string): Promise<GovernmentSearchResult[] | null> {
  if (!isSupabaseConfigured()) return null;

  try {
    const normalizedQuery = query.toLowerCase().trim();
    const now = new Date().toISOString();

    const { data, error } = await supabase
      .from('bill_cache')
      .select('*')
      .eq('search_query', normalizedQuery)
      .gt('expires_at', now)
      .order('created_at', { ascending: false });

    // If table doesn't exist or other error, just return null (cache miss)
    if (error) {
      // Only log if it's not a "relation does not exist" error (table not created yet)
      if (!error.message?.includes('does not exist')) {
        console.log('Cache lookup skipped:', error.message ?? 'Unknown error');
      }
      return null;
    }

    if (!data || data.length === 0) {
      return null;
    }

    const cachedData = data as unknown as CachedBill[];
    console.log(`Cache HIT: Found ${cachedData.length} cached results for "${query}" (Cost: $0)`);

    // Convert cached data to GovernmentSearchResult format
    return cachedData.map((cached): GovernmentSearchResult => ({
      id: cached.bill_id,
      branch: 'legislative',
      title: cached.title,
      shortTitle: cached.short_title,
      date: cached.date,
      status: cached.status,
      statusLabel: determineStatusLabel(cached.status),
      category: cached.category,
      sourceUrl: cached.source_url,
      rawText: cached.raw_text,
      metadata: cached.metadata,
    }));
  } catch {
    // Silently fail - cache is optional optimization
    return null;
  }
}

/**
 * Check bill_cache for a specific bill by ID
 */
async function getCachedBillById(billId: string): Promise<GovernmentSearchResult | null> {
  if (!isSupabaseConfigured()) return null;

  try {
    const now = new Date().toISOString();

    const { data, error } = await supabase
      .from('bill_cache')
      .select('*')
      .eq('bill_id', billId)
      .gt('expires_at', now)
      .single();

    // Silently handle errors (table might not exist yet)
    if (error || !data) return null;

    const cached = data as unknown as CachedBill;
    console.log(`Cache HIT: Found cached bill ${billId} (Cost: $0)`);

    return {
      id: cached.bill_id,
      branch: 'legislative',
      title: cached.title,
      shortTitle: cached.short_title,
      date: cached.date,
      status: cached.status,
      statusLabel: determineStatusLabel(cached.status),
      category: cached.category,
      sourceUrl: cached.source_url,
      rawText: cached.raw_text,
      metadata: cached.metadata,
    };
  } catch {
    // Silently fail - cache is optional optimization
    return null;
  }
}

/**
 * Save search results to bill_cache for future free lookups
 * Silently fails if table doesn't exist - cache is optional optimization
 */
async function cacheSearchResults(
  query: string,
  results: GovernmentSearchResult[]
): Promise<void> {
  if (!isSupabaseConfigured() || results.length === 0) return;

  try {
    const normalizedQuery = query.toLowerCase().trim();
    const now = new Date();
    const expiresAt = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000); // 7 days

    const cacheEntries = results.map((result) => {
      const metadata = result.metadata as Record<string, unknown>;
      return {
        search_query: normalizedQuery,
        bill_id: result.id,
        congress: (metadata.congress as number) ?? 119,
        bill_type: (metadata.type as string) ?? 'hr',
        bill_number: (metadata.number as number) ?? 0,
        title: result.title,
        short_title: result.shortTitle,
        status: result.status,
        category: result.category,
        date: result.date,
        source_url: result.sourceUrl,
        raw_text: result.rawText,
        metadata: JSON.stringify(result.metadata),
        created_at: now.toISOString(),
        expires_at: expiresAt.toISOString(),
      };
    });

    // Upsert to avoid duplicates (update if bill_id exists)
    const { error } = await supabase
      .from('bill_cache')
      .upsert(cacheEntries as never[], {
        onConflict: 'bill_id',
        ignoreDuplicates: false,
      });

    // Only log if successful or if it's NOT a "table doesn't exist" error
    if (error) {
      if (!error.message?.includes('does not exist')) {
        console.log('Cache save skipped:', error.message ?? 'Unknown error');
      }
      // Silently skip caching if table doesn't exist
    } else {
      console.log(`Cached ${results.length} results for "${query}" - next lookup is FREE`);
    }
  } catch {
    // Silently fail - cache is optional optimization
  }
}

// ===========================================
// LEGISLATIVE - Congress.gov API (Direct Search)
// ===========================================

export async function searchLegislation(query: string, limit = 20): Promise<GovernmentSearchResult[]> {
  try {
    console.log(`Congress.gov search: "${query}"`);

    // STEP 1: Check cache first (Cost: $0)
    const cachedResults = await getCachedSearchResults(query);
    if (cachedResults && cachedResults.length > 0) {
      // Sort by date (newest first)
      return cachedResults
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, limit);
    }

    // STEP 2: Use Congress.gov's bill search endpoint with proper parameters
    // The API uses 'q' for keyword search across bill titles and text
    console.log('Cache miss - searching Congress.gov directly...');

    // Build search URL with correct parameters
    // Congress.gov API v3 uses different endpoints for search vs listing
    // For keyword search, we need to use the search endpoint format
    const searchParams = new URLSearchParams({
      api_key: API_KEYS.congress,
      limit: limit.toString(),
      sort: 'updateDate desc', // Newest first
      format: 'json',
    });

    // Try the bill search with query parameter first
    let searchUrl = `https://api.congress.gov/v3/bill?${searchParams.toString()}&q=${encodeURIComponent(query)}`;
    console.log('Congress.gov search URL:', searchUrl.replace(API_KEYS.congress, 'API_KEY'));

    let response = await fetch(searchUrl, {
      headers: { 'Accept': 'application/json' },
    });

    let data: CongressSearchResponse | null = null;

    if (response.ok) {
      data = await response.json();
    }

    // If no results or failed, try alternate search approach
    if (!data?.bills || data.bills.length === 0) {
      console.log('Primary search returned no results, trying keyword search...');

      // Try searching across multiple congresses with the search term
      const keywordUrl = `https://api.congress.gov/v3/bill?api_key=${API_KEYS.congress}&limit=${limit}&sort=updateDate+desc&format=json`;

      response = await fetch(keywordUrl, {
        headers: { 'Accept': 'application/json' },
      });

      if (response.ok) {
        const allBills: CongressSearchResponse = await response.json();

        // Filter bills that match the query in title
        const queryLower = query.toLowerCase();
        const queryWords = queryLower.split(/\s+/).filter(w => w.length > 2);

        if (allBills.bills && Array.isArray(allBills.bills)) {
          const matchedBills = allBills.bills.filter(bill => {
            const titleLower = (bill.title ?? '').toLowerCase();
            const policyLower = (bill.policyArea?.name ?? '').toLowerCase();

            // Check if any query word matches
            return queryWords.some(word =>
              titleLower.includes(word) || policyLower.includes(word)
            );
          });

          if (matchedBills.length > 0) {
            data = { bills: matchedBills, pagination: { count: matchedBills.length } };
            console.log(`Keyword filter matched ${matchedBills.length} bills`);
          }
        }
      }
    }

    if (!data?.bills || !Array.isArray(data.bills) || data.bills.length === 0) {
      console.log('No bills found for query, showing recent bills');
      return fetchRecentBills(limit);
    }

    console.log(`Congress.gov returned ${data.bills.length} bills for "${query}"`);

    // Use a Set to track seen bills and ensure uniqueness
    const seenBills = new Set<string>();

    const results = data.bills
      .filter((bill) => {
        const billKey = `${bill.congress ?? 119}-${bill.type ?? 'hr'}-${bill.number ?? ''}`;
        if (seenBills.has(billKey)) {
          return false;
        }
        seenBills.add(billKey);
        return true;
      })
      .map((bill): GovernmentSearchResult => {
        const billType = (bill.type ?? 'hr').toLowerCase();
        const congress = bill.congress ?? 119;
        const billNum = bill.number ?? 0;
        const congressNumber = `${bill.type ?? 'HR'}.${billNum}`;

        const chamberSlug = billType.startsWith('s') && !['sconres', 'sres', 'sjres'].includes(billType) ? 'senate-bill' :
                            billType === 'hr' ? 'house-bill' :
                            billType === 'hres' ? 'house-resolution' :
                            billType === 'sres' ? 'senate-resolution' :
                            billType === 'hjres' ? 'house-joint-resolution' :
                            billType === 'sjres' ? 'senate-joint-resolution' :
                            billType === 'hconres' ? 'house-concurrent-resolution' :
                            billType === 'sconres' ? 'senate-concurrent-resolution' :
                            billType === 's' ? 'senate-bill' : 'house-bill';
        const publicUrl = `https://www.congress.gov/bill/${congress}th-congress/${chamberSlug}/${billNum}`;

        const uniqueId = `congress-${congress}-${billType}-${billNum}`;

        return {
          id: uniqueId,
          branch: 'legislative',
          title: bill.title ?? 'Untitled Bill',
          shortTitle: (bill.title ?? 'Untitled Bill').length > 80 ? `${(bill.title ?? 'Untitled Bill').slice(0, 80)}...` : (bill.title ?? 'Untitled Bill'),
          date: bill.latestAction?.actionDate ?? bill.introducedDate ?? '',
          status: bill.latestAction?.text ?? 'Introduced',
          statusLabel: determineStatusLabel(bill.latestAction?.text),
          category: mapPolicyAreaToCategory(bill.policyArea?.name),
          sourceUrl: publicUrl,
          rawText: `${bill.title ?? 'Untitled Bill'}. ${bill.policyArea?.name ? `Policy Area: ${bill.policyArea.name}.` : ''} ${bill.originChamber ? `Originated in the ${bill.originChamber}.` : ''} ${bill.latestAction?.text ? `Latest action: ${bill.latestAction.text}` : ''}`.trim(),
          metadata: {
            congress: bill.congress,
            type: bill.type,
            number: bill.number,
            chamber: bill.originChamber,
            congressNumber,
            policyArea: bill.policyArea?.name,
          },
        };
      });

    // Cache the results
    await cacheSearchResults(query, results);

    return results;
  } catch (error) {
    console.error('Error in Congress.gov search:', error);
    return fetchRecentBills(limit);
  }
}

// Fallback function to get recent bills when search fails
async function fetchRecentBills(limit: number): Promise<GovernmentSearchResult[]> {
  try {
    const url = `https://api.congress.gov/v3/bill?api_key=${API_KEYS.congress}&limit=${limit}&sort=updateDate+desc&format=json`;

    const response = await fetch(url, {
      headers: { 'Accept': 'application/json' },
    });

    if (!response.ok) return [];

    const data: CongressSearchResponse = await response.json();

    if (!data.bills || !Array.isArray(data.bills)) return [];

    // Use a Set to track seen bills and ensure uniqueness
    const seenBills = new Set<string>();

    return data.bills
      .filter((bill) => {
        // Generate unique key based on bill data
        const billKey = `${bill.congress ?? 119}-${bill.type ?? 'hr'}-${bill.number ?? ''}`;
        if (seenBills.has(billKey)) {
          return false; // Skip duplicate
        }
        seenBills.add(billKey);
        return true;
      })
      .map((bill): GovernmentSearchResult => {
        const billType = (bill.type ?? 'hr').toLowerCase();
        const congress = bill.congress ?? 119;
        const billNum = bill.number ?? 0;
        const congressNumber = `${bill.type ?? 'HR'}.${billNum}`;

        const chamberSlug = billType.startsWith('s') ? 'senate-bill' :
                            billType === 'hr' ? 'house-bill' :
                            billType === 'hres' ? 'house-resolution' :
                            billType === 'sres' ? 'senate-resolution' :
                            billType === 'hjres' ? 'house-joint-resolution' :
                            billType === 'sjres' ? 'senate-joint-resolution' :
                            billType === 'hconres' ? 'house-concurrent-resolution' :
                            billType === 'sconres' ? 'senate-concurrent-resolution' : 'house-bill';
        const publicUrl = `https://www.congress.gov/bill/${congress}th-congress/${chamberSlug}/${billNum}`;

        // Generate unique ID based on actual bill data, not index
        const uniqueId = `congress-${congress}-${billType}-${billNum}`;

        return {
          id: uniqueId,
          branch: 'legislative',
          title: bill.title ?? 'Untitled Bill',
          shortTitle: (bill.title ?? 'Untitled Bill').length > 80 ? `${(bill.title ?? 'Untitled Bill').slice(0, 80)}...` : (bill.title ?? 'Untitled Bill'),
          date: bill.latestAction?.actionDate ?? bill.introducedDate ?? '',
          status: bill.latestAction?.text ?? 'Introduced',
          statusLabel: determineStatusLabel(bill.latestAction?.text),
          category: mapPolicyAreaToCategory(bill.policyArea?.name),
          sourceUrl: publicUrl,
          rawText: `${bill.title ?? 'Untitled Bill'}. ${bill.policyArea?.name ? `Policy Area: ${bill.policyArea.name}.` : ''} ${bill.originChamber ? `Originated in the ${bill.originChamber}.` : ''} ${bill.latestAction?.text ? `Latest action: ${bill.latestAction.text}` : ''}`.trim(),
          metadata: {
            congress: bill.congress,
            type: bill.type,
            number: bill.number,
            chamber: bill.originChamber,
            congressNumber,
            policyArea: bill.policyArea?.name,
          },
        };
      });
  } catch {
    return [];
  }
}

// ===========================================
// EXECUTIVE - Federal Register API
// ===========================================

export async function searchExecutive(query: string, limit = 20): Promise<GovernmentSearchResult[]> {
  try {
    const params = new URLSearchParams({
      'conditions[term]': query,
      'conditions[type][]': 'PRESDOCU',
      'per_page': limit.toString(),
      'order': 'newest', // Sort by newest first
    });

    const url = `https://www.federalregister.gov/api/v1/documents.json?${params.toString()}`;
    console.log('Federal Register search URL:', url);

    const response = await fetch(
      url,
      {
        headers: {
          'Accept': 'application/json',
        },
      }
    );

    if (!response.ok) {
      console.error('Federal Register API error:', response.status, response.statusText);
      return [];
    }

    const data: FederalRegisterResponse = await response.json();

    // Handle empty or missing results
    if (!data.results || !Array.isArray(data.results)) {
      return [];
    }

    return data.results.map((item): GovernmentSearchResult => {
      const eoNumber = item.executive_order_number
        ? `EO ${item.executive_order_number}`
        : item.document_number;

      // Determine executive order status
      const eoStatus: LegislativeStatus = item.type === 'Presidential Document' ? 'active' : 'proposed';

      return {
        id: `federal-register-${item.document_number}`,
        branch: 'executive',
        title: item.title ?? 'Untitled Document',
        shortTitle: (item.title ?? 'Untitled Document').length > 80 ? `${(item.title ?? 'Untitled Document').slice(0, 80)}...` : (item.title ?? 'Untitled Document'),
        date: item.signing_date ?? item.publication_date ?? '',
        status: item.type === 'Presidential Document' ? 'active' : (item.type ?? 'unknown'),
        statusLabel: eoStatus,
        category: mapExecutiveTypeToCategory(item.subtype, item.agencies?.map(a => a.name)),
        sourceUrl: item.html_url ?? 'https://www.federalregister.gov',
        rawText: item.abstract ?? item.title ?? 'No details available',
        metadata: {
          documentNumber: item.document_number,
          eoNumber,
          president: item.president?.name,
          publicationDate: item.publication_date,
          signingDate: item.signing_date,
          type: item.type,
          subtype: item.subtype,
          pdfUrl: item.pdf_url,
          agencies: item.agencies?.map(a => a.name),
        },
      };
    });
  } catch (error) {
    console.error('Error fetching from Federal Register:', error);
    return [];
  }
}

// ===========================================
// JUDICIAL - CourtListener API
// ===========================================

export async function searchJudicial(query: string, limit = 20): Promise<GovernmentSearchResult[]> {
  try {
    // Search ALL federal courts, not just SCOTUS
    // This includes Circuit Courts, District Courts, etc.
    const params = new URLSearchParams({
      q: query,
      type: 'o', // opinions
      // Remove court filter to search all courts
      order_by: 'dateFiled desc', // Sort by date (newest first)
      page_size: limit.toString(),
    });

    const url = `https://www.courtlistener.com/api/rest/v4/search/?${params.toString()}`;
    console.log('CourtListener search URL:', url.replace(API_KEYS.courtListener, 'API_KEY'));

    const response = await fetch(
      url,
      {
        headers: {
          'Accept': 'application/json',
          'Authorization': `Token ${API_KEYS.courtListener}`,
        },
      }
    );

    if (!response.ok) {
      console.error('CourtListener API error:', response.status, response.statusText);
      return [];
    }

    const data: CourtListenerResponse = await response.json();

    // Handle empty or missing results
    if (!data.results || !Array.isArray(data.results)) {
      return [];
    }

    // Sort by date (newest first) and map results
    const sortedResults = [...data.results].sort((a, b) => {
      const dateA = new Date(a.dateFiled ?? a.dateArgued ?? '1900-01-01').getTime();
      const dateB = new Date(b.dateFiled ?? b.dateArgued ?? '1900-01-01').getTime();
      return dateB - dateA;
    });

    return sortedResults.map((item, index): GovernmentSearchResult => {
      // CourtListener may return id in different formats - ensure we have a unique key
      const itemId = item.id ?? item.docketNumber ?? `index-${index}`;

      // Determine judicial status
      const judicialStatus: LegislativeStatus = item.status === 'decided' || item.status === 'Published' ? 'landmark' : 'pending';

      // Get court name for display
      const courtName = item.court ?? 'Federal Court';

      return {
        id: `courtlistener-${itemId}-${index}`,
        branch: 'judicial',
        title: item.caseName ?? 'Unknown Case',
        shortTitle: (item.caseName ?? 'Unknown Case').length > 80 ? `${(item.caseName ?? 'Unknown Case').slice(0, 80)}...` : (item.caseName ?? 'Unknown Case'),
        date: item.dateFiled ?? item.dateArgued ?? '',
        status: item.status ?? 'decided',
        statusLabel: judicialStatus,
        category: 'civil_rights', // Default for court cases
        sourceUrl: item.absolute_url ? `https://www.courtlistener.com${item.absolute_url}` : 'https://www.courtlistener.com',
        rawText: item.snippet ?? item.caseName ?? 'No details available',
        metadata: {
          docketNumber: item.docketNumber,
          court: courtName,
          dateArgued: item.dateArgued,
          dateFiled: item.dateFiled,
          suitNature: item.suitNature,
        },
      };
    });
  } catch (error) {
    console.error('Error fetching from CourtListener:', error);
    return [];
  }
}

// ===========================================
// UNIFIED SEARCH ROUTER
// ===========================================

export async function searchGovernment(
  branch: SearchBranch,
  query: string,
  limit = 20
): Promise<GovernmentSearchResult[]> {
  if (!query.trim()) {
    return [];
  }

  switch (branch) {
    case 'legislative':
      return searchLegislation(query, limit);
    case 'executive':
      return searchExecutive(query, limit);
    case 'judicial':
      return searchJudicial(query, limit);
    default:
      return [];
  }
}

// ===========================================
// FETCH SINGLE DOCUMENT DETAILS
// ===========================================

export async function fetchDocumentDetails(
  branch: SearchBranch,
  documentId: string
): Promise<GovernmentSearchResult | null> {
  try {
    switch (branch) {
      case 'legislative': {
        // Extract congress and bill number from ID
        const match = documentId.match(/congress-(\d+)-(.+)-\d+$/);
        if (!match) return null;

        const [, congress, billPart] = match;
        // billPart could be "HR.123" or "S.456" etc.
        const billMatch = billPart.match(/([A-Z]+)\.(\d+)/i);
        if (!billMatch) return null;

        const [, billTypeRaw, billNumber] = billMatch;
        const billType = billTypeRaw.toLowerCase();

        // Fetch bill details
        const response = await fetch(
          `https://api.congress.gov/v3/bill/${congress}/${billType}/${billNumber}?api_key=${API_KEYS.congress}`,
          { headers: { 'Accept': 'application/json' } }
        );

        if (!response.ok) return null;

        const data = await response.json();
        const bill = data.bill;

        // Also try to fetch the summary for better preview content
        let summaryText = '';
        try {
          const summaryResponse = await fetch(
            `https://api.congress.gov/v3/bill/${congress}/${billType}/${billNumber}/summaries?api_key=${API_KEYS.congress}`,
            { headers: { 'Accept': 'application/json' } }
          );
          if (summaryResponse.ok) {
            const summaryData = await summaryResponse.json();
            // Get the most recent summary (they're usually sorted by version)
            const summaries = summaryData.summaries ?? [];
            if (summaries.length > 0) {
              // Strip HTML tags from summary text
              summaryText = (summaries[summaries.length - 1]?.text ?? '').replace(/<[^>]*>/g, '');
            }
          }
        } catch {
          // Summary fetch failed - continue without it
        }

        // Build human-readable Congress.gov URL
        const chamberSlug = billType.startsWith('s') ? 'senate-bill' :
                            billType === 'hr' ? 'house-bill' :
                            billType === 'hres' ? 'house-resolution' :
                            billType === 'sres' ? 'senate-resolution' :
                            billType === 'hjres' ? 'house-joint-resolution' :
                            billType === 'sjres' ? 'senate-joint-resolution' :
                            billType === 'hconres' ? 'house-concurrent-resolution' :
                            billType === 'sconres' ? 'senate-concurrent-resolution' : 'house-bill';
        const publicUrl = `https://www.congress.gov/bill/${congress}th-congress/${chamberSlug}/${billNumber}`;

        // Build rich rawText for AI preview
        const rawTextParts = [bill.title];
        if (bill.policyArea?.name) rawTextParts.push(`Policy Area: ${bill.policyArea.name}.`);
        if (summaryText) rawTextParts.push(`Summary: ${summaryText}`);
        if (bill.latestAction?.text) rawTextParts.push(`Latest action: ${bill.latestAction.text}`);

        return {
          id: documentId,
          branch: 'legislative',
          title: bill.title,
          shortTitle: bill.title.length > 80 ? `${bill.title.slice(0, 80)}...` : bill.title,
          date: bill.latestAction?.actionDate ?? bill.introducedDate,
          status: bill.latestAction?.text ?? 'Introduced',
          statusLabel: determineStatusLabel(bill.latestAction?.text),
          category: mapPolicyAreaToCategory(bill.policyArea?.name),
          sourceUrl: publicUrl,
          rawText: rawTextParts.join(' '),
          metadata: {
            congress: bill.congress,
            sponsors: bill.sponsors,
            cosponsors: bill.cosponsors,
            committees: bill.committees,
            actions: bill.actions,
            policyArea: bill.policyArea?.name,
            summary: summaryText || undefined,
          },
        };
      }

      case 'executive': {
        const docNumber = documentId.replace('federal-register-', '');
        const response = await fetch(
          `https://www.federalregister.gov/api/v1/documents/${docNumber}.json`,
          { headers: { 'Accept': 'application/json' } }
        );

        if (!response.ok) return null;

        const item: FederalRegisterResult = await response.json();

        return {
          id: documentId,
          branch: 'executive',
          title: item.title,
          shortTitle: item.title.length > 80 ? `${item.title.slice(0, 80)}...` : item.title,
          date: item.signing_date ?? item.publication_date,
          status: 'active',
          statusLabel: 'active' as LegislativeStatus,
          category: mapExecutiveTypeToCategory(item.subtype, item.agencies?.map(a => a.name)),
          sourceUrl: item.html_url,
          rawText: item.abstract ?? item.title,
          metadata: {
            documentNumber: item.document_number,
            eoNumber: item.executive_order_number ? `EO ${item.executive_order_number}` : item.document_number,
            president: item.president?.name,
            fullTextUrl: item.raw_text_url,
            pdfUrl: item.pdf_url,
          },
        };
      }

      case 'judicial': {
        const opinionId = documentId.replace('courtlistener-', '');
        const response = await fetch(
          `https://www.courtlistener.com/api/rest/v4/opinions/${opinionId}/`,
          {
            headers: {
              'Accept': 'application/json',
              'Authorization': `Token ${API_KEYS.courtListener}`,
            },
          }
        );

        if (!response.ok) return null;

        const item = await response.json();

        return {
          id: documentId,
          branch: 'judicial',
          title: item.case_name ?? `Case ${opinionId}`,
          shortTitle: (item.case_name ?? `Case ${opinionId}`).slice(0, 80),
          date: item.date_filed ?? '',
          status: 'decided',
          statusLabel: 'landmark' as LegislativeStatus,
          category: 'civil_rights',
          sourceUrl: `https://www.courtlistener.com${item.absolute_url}`,
          rawText: item.plain_text ?? item.html ?? item.case_name,
          metadata: {
            docketNumber: item.docket,
            judges: item.judges,
            citations: item.citations,
          },
        };
      }

      default:
        return null;
    }
  } catch (error) {
    console.error('Error fetching document details:', error);
    return null;
  }
}

// ===========================================
// EXPORT API KEYS FOR AI SERVICE
// ===========================================

export const getOpenAIKey = () => API_KEYS.openai;

// ===========================================
// FETCH BILL SPONSOR FROM CONGRESS.GOV
// ===========================================

export interface SponsorInfo {
  name: string;
  party: string;
  state: string;
  district?: string;
  bioguideId?: string;
  imageUrl?: string;
}

export async function fetchBillSponsor(sourceUrl: string): Promise<SponsorInfo | null> {
  try {
    // Extract bill info from Congress.gov URL
    // URL format: https://www.congress.gov/bill/118th-congress/house-bill/1234
    const urlMatch = sourceUrl.match(/congress\.gov\/bill\/(\d+)(?:th|st|nd|rd)-congress\/(house|senate)-bill\/(\d+)/i);

    if (!urlMatch) {
      console.log('Could not parse Congress.gov URL:', sourceUrl);
      return null;
    }

    const [, congress, chamber, billNumber] = urlMatch;
    const billType = chamber.toLowerCase() === 'house' ? 'hr' : 's';

    // Fetch bill details from Congress.gov API
    const response = await fetch(
      `https://api.congress.gov/v3/bill/${congress}/${billType}/${billNumber}?api_key=${API_KEYS.congress}`,
      { headers: { 'Accept': 'application/json' } }
    );

    if (!response.ok) {
      console.log('Congress API error:', response.status);
      return null;
    }

    const data = await response.json();
    const bill = data.bill;

    if (!bill?.sponsors || bill.sponsors.length === 0) {
      console.log('No sponsors found for bill');
      return null;
    }

    const sponsor = bill.sponsors[0];

    return {
      name: sponsor.fullName ?? sponsor.firstName + ' ' + sponsor.lastName,
      party: sponsor.party ?? 'Unknown',
      state: sponsor.state ?? '',
      district: sponsor.district,
      bioguideId: sponsor.bioguideId,
      imageUrl: sponsor.bioguideId
        ? `https://www.congress.gov/img/member/${sponsor.bioguideId.toLowerCase()}_200.jpg`
        : undefined,
    };
  } catch (error) {
    console.error('Error fetching bill sponsor:', error);
    return null;
  }
}
