import type { Bill, CitizensBrief } from './types';
import type { GovernmentSearchResult, SearchBranch } from './government-api';
import { getOpenAIKey } from './government-api';

const GEMINI_API_KEY = process.env.EXPO_PUBLIC_VIBECODE_GOOGLE_API_KEY;
const OPENAI_API_KEY = process.env.EXPO_PUBLIC_VIBECODE_OPENAI_API_KEY;

// Get the hardcoded key from government-api for Library Gateway
const LIBRARY_OPENAI_KEY = getOpenAIKey();

interface AIResponse {
  success: boolean;
  data?: string;
  error?: string;
}

interface BillAnalysis {
  summary: string;
  pros: string[];
  cons: string[];
  impactedGroups: string[];
  keyPoints: string[];
}

interface QuestionAnswer {
  answer: string;
  confidence: 'high' | 'medium' | 'low';
  sources?: string[];
}

/**
 * Generate a plain English explanation of a bill using Gemini
 */
export async function generateBillExplanation(bill: Bill): Promise<AIResponse> {
  if (!GEMINI_API_KEY) {
    return { success: false, error: 'Gemini API key not configured' };
  }

  try {
    const response = await fetch(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-preview:generateContent',
      {
        method: 'POST',
        headers: {
          'x-goog-api-key': GEMINI_API_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          system_instruction: {
            parts: [{
              text: `You are a civic education expert who explains legislation to everyday citizens.
Your goal is to make complex legal language accessible without being condescending.
Be balanced and non-partisan. Focus on facts and practical implications.
Keep explanations concise but thorough - around 150-200 words.`
            }]
          },
          contents: [{
            role: 'user',
            parts: [{
              text: `Please explain this bill in plain English that a high school student could understand:

Title: ${bill.title}
Short Title: ${bill.shortTitle}
Category: ${bill.category}
Status: ${bill.status}
Sponsor: ${bill.sponsor.name} (${bill.sponsor.party}-${bill.sponsor.state})

Full Text Summary:
${bill.fullText.substring(0, 2000)}

Focus on:
1. What this bill actually does
2. Who it affects
3. Why it matters`
            }]
          }],
          generationConfig: {
            temperature: 1.0,
            maxOutputTokens: 500,
          }
        }),
      }
    );

    if (!response.ok) {
      const errorData = await response.text();
      console.log('Gemini API error:', errorData);
      return { success: false, error: 'Failed to generate explanation' };
    }

    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text ?? '';

    return { success: true, data: text };
  } catch (error) {
    console.log('AI explanation error:', error);
    return { success: false, error: 'Network error generating explanation' };
  }
}

/**
 * Analyze a bill for pros, cons, and impacted groups using GPT
 */
export async function analyzeBillImpact(bill: Bill): Promise<{ success: boolean; data?: BillAnalysis; error?: string }> {
  if (!OPENAI_API_KEY) {
    return { success: false, error: 'OpenAI API key not configured' };
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-5.2',
        messages: [
          {
            role: 'system',
            content: `You are a non-partisan policy analyst. Analyze legislation objectively, presenting both sides fairly.
Return your analysis as valid JSON with this exact structure:
{
  "summary": "2-3 sentence overview",
  "pros": ["benefit 1", "benefit 2", "benefit 3"],
  "cons": ["concern 1", "concern 2", "concern 3"],
  "impactedGroups": ["group 1", "group 2"],
  "keyPoints": ["point 1", "point 2", "point 3"]
}`
          },
          {
            role: 'user',
            content: `Analyze this legislation:

Title: ${bill.title}
Category: ${bill.category}
Chamber: ${bill.chamber}
Status: ${bill.status}

Text:
${bill.fullText.substring(0, 3000)}

Provide a balanced analysis with pros, cons, impacted groups, and key points.`
          }
        ],
        max_completion_tokens: 800,
        temperature: 1,
      }),
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.log('OpenAI API error:', errorData);
      return { success: false, error: 'Failed to analyze bill' };
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content ?? '';

    // Try to parse JSON from the response
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const analysis = JSON.parse(jsonMatch[0]) as BillAnalysis;
        return { success: true, data: analysis };
      }
    } catch {
      // If JSON parsing fails, create a structured response from text
      return {
        success: true,
        data: {
          summary: content.substring(0, 200),
          pros: ['Analysis available', 'Review full text for details'],
          cons: ['Consider multiple perspectives'],
          impactedGroups: ['Various stakeholders'],
          keyPoints: ['See full analysis'],
        },
      };
    }

    return { success: false, error: 'Could not parse analysis' };
  } catch (error) {
    console.log('AI analysis error:', error);
    return { success: false, error: 'Network error analyzing bill' };
  }
}

/**
 * Answer a user's question about a specific bill
 */
export async function askAboutBill(bill: Bill, question: string): Promise<{ success: boolean; data?: QuestionAnswer; error?: string }> {
  if (!GEMINI_API_KEY) {
    return { success: false, error: 'API key not configured' };
  }

  try {
    const response = await fetch(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-preview:generateContent',
      {
        method: 'POST',
        headers: {
          'x-goog-api-key': GEMINI_API_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          system_instruction: {
            parts: [{
              text: `You are a helpful civic assistant answering questions about legislation.
Be accurate, balanced, and acknowledge uncertainty when appropriate.
Keep answers concise (100-150 words) and accessible to general audiences.
Return JSON: {"answer": "your response", "confidence": "high|medium|low"}`
            }]
          },
          contents: [{
            role: 'user',
            parts: [{
              text: `Bill: ${bill.shortTitle}
Title: ${bill.title}
Category: ${bill.category}
Text excerpt: ${bill.fullText.substring(0, 1500)}

User question: ${question}

Provide a helpful, accurate answer.`
            }]
          }],
          generationConfig: {
            temperature: 1.0,
            maxOutputTokens: 300,
            responseMimeType: 'application/json',
            responseSchema: {
              type: 'object',
              properties: {
                answer: { type: 'string' },
                confidence: { type: 'string', enum: ['high', 'medium', 'low'] }
              }
            }
          }
        }),
      }
    );

    if (!response.ok) {
      return { success: false, error: 'Failed to get answer' };
    }

    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text ?? '';

    try {
      const parsed = JSON.parse(text) as QuestionAnswer;
      return { success: true, data: parsed };
    } catch {
      return {
        success: true,
        data: { answer: text, confidence: 'medium' }
      };
    }
  } catch (error) {
    console.log('AI question error:', error);
    return { success: false, error: 'Network error' };
  }
}

/**
 * Generate a debate-style comparison of arguments for/against a bill
 */
export async function generateDebatePoints(bill: Bill): Promise<AIResponse> {
  if (!OPENAI_API_KEY) {
    return { success: false, error: 'API key not configured' };
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-5.2',
        messages: [
          {
            role: 'system',
            content: `You are a debate moderator presenting the strongest arguments from both sides of a legislative issue.
Be fair, balanced, and present each side's best arguments without taking a position.
Format: Start with "FOR:" followed by 3 bullet points, then "AGAINST:" with 3 bullet points.`
          },
          {
            role: 'user',
            content: `Present the strongest arguments for and against this bill:

${bill.shortTitle}: ${bill.title}

${bill.simplifiedText}

Category: ${bill.category}
Current Status: ${bill.status}`
          }
        ],
        max_completion_tokens: 600,
        temperature: 1,
      }),
    });

    if (!response.ok) {
      return { success: false, error: 'Failed to generate debate points' };
    }

    const data = await response.json();
    const text = data.choices?.[0]?.message?.content ?? '';

    return { success: true, data: text };
  } catch (error) {
    console.log('AI debate error:', error);
    return { success: false, error: 'Network error' };
  }
}

/**
 * Check if AI services are available
 */
export function getAIAvailability(): { gemini: boolean; openai: boolean } {
  return {
    gemini: !!GEMINI_API_KEY,
    openai: !!OPENAI_API_KEY,
  };
}

/**
 * Generate a Citizen's Brief - AI-simplified bill summary
 * Format:
 * - The Goal: What is this bill trying to do?
 * - The Wallet: How much taxpayer money does this cost or save?
 * - The Debate: What are the two main arguments for and against it?
 */
export async function generateCitizensBrief(bill: Bill): Promise<{ success: boolean; data?: CitizensBrief; error?: string }> {
  // Try OpenAI first, then Gemini
  const apiKey = OPENAI_API_KEY ?? GEMINI_API_KEY;
  const useOpenAI = !!OPENAI_API_KEY;

  if (!apiKey) {
    return { success: false, error: 'No AI API key configured' };
  }

  const prompt = `Analyze this congressional bill and create a "Citizen's Brief" - a non-partisan, accessible summary for everyday Americans.

Bill: ${bill.congressNumber ?? bill.shortTitle}
Title: ${bill.title}
Category: ${bill.category}
Status: ${bill.status}
Chamber: ${bill.chamber}

Full Text:
${bill.fullText.substring(0, 3000)}

Create a Citizen's Brief with EXACTLY these three sections:

1. THE GOAL: What is this bill trying to do? (2-3 sentences, plain English)
2. THE WALLET: How much taxpayer money does this cost or save? Be specific with numbers if available. If unknown, explain what financial impact is expected.
3. THE DEBATE: What are the strongest arguments FOR and AGAINST this bill? Present both sides fairly in 2-3 sentences each.

Return as JSON:
{
  "theGoal": "...",
  "theWallet": "...",
  "theDebate": "..."
}`;

  try {
    if (useOpenAI) {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-5.2',
          messages: [
            {
              role: 'system',
              content: 'You are a non-partisan civic education expert who explains legislation to everyday citizens. Be balanced, factual, and accessible. Always return valid JSON.',
            },
            { role: 'user', content: prompt },
          ],
          max_completion_tokens: 800,
          temperature: 0.7,
        }),
      });

      if (!response.ok) {
        return { success: false, error: 'Failed to generate brief' };
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content ?? '';

      try {
        const jsonMatch = content.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          const brief = JSON.parse(jsonMatch[0]) as CitizensBrief;
          return { success: true, data: brief };
        }
      } catch {
        // Parse error - return structured fallback
      }
    } else {
      // Use Gemini
      const response = await fetch(
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-preview:generateContent',
        {
          method: 'POST',
          headers: {
            'x-goog-api-key': GEMINI_API_KEY ?? '',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            system_instruction: {
              parts: [{
                text: 'You are a non-partisan civic education expert. Always return valid JSON.',
              }],
            },
            contents: [{
              role: 'user',
              parts: [{ text: prompt }],
            }],
            generationConfig: {
              temperature: 0.7,
              maxOutputTokens: 800,
              responseMimeType: 'application/json',
            },
          }),
        }
      );

      if (!response.ok) {
        return { success: false, error: 'Failed to generate brief' };
      }

      const data = await response.json();
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text ?? '';

      try {
        const brief = JSON.parse(text) as CitizensBrief;
        return { success: true, data: brief };
      } catch {
        // Parse error
      }
    }

    // Fallback if parsing fails
    return {
      success: true,
      data: {
        theGoal: `This bill (${bill.shortTitle}) aims to address issues related to ${bill.category}. Review the full text for complete details.`,
        theWallet: 'Fiscal impact analysis pending. Check the Congressional Budget Office for official cost estimates.',
        theDebate: 'Supporters argue this legislation addresses important needs. Critics raise concerns about implementation. Consider multiple perspectives before forming your opinion.',
      },
    };
  } catch (error) {
    console.log('Citizens Brief generation error:', error);
    return { success: false, error: 'Network error generating brief' };
  }
}

// ===========================================
// LIBRARY GATEWAY: Convert to Post
// ===========================================

export interface LibraryPostContent {
  citizensBrief: string; // 3-sentence AI summary
  representationGap: string; // "What do YOU think?" prompt
  title: string;
  branch: SearchBranch;
  sourceUrl: string;
  sourceId: string;
  category: string;
}

/**
 * Convert a government document to a shareable Post
 * Generates an enhanced Citizen's Brief by searching for the bill/order name
 */
export async function convertToPost(
  document: GovernmentSearchResult
): Promise<{ success: boolean; data?: LibraryPostContent; error?: string }> {
  const branchLabels: Record<SearchBranch, string> = {
    legislative: 'Congressional Bill',
    executive: 'Executive Order',
    judicial: 'Supreme Court Case',
  };

  // Helper to create fallback content
  const createFallback = (): LibraryPostContent => ({
    citizensBrief: `${document.shortTitle} is a ${branchLabels[document.branch].toLowerCase()} that addresses ${document.category.replace('_', ' ')} policy. It was ${document.status} on ${document.date || 'a recent date'}. Review the official source to understand its full implications.`,
    representationGap: `Do you think this ${branchLabels[document.branch].toLowerCase()} represents the will of the people?`,
    title: document.shortTitle,
    branch: document.branch,
    sourceUrl: document.sourceUrl,
    sourceId: document.id,
    category: document.category,
  });

  // Use environment variable for OpenAI
  const apiKey = process.env.EXPO_PUBLIC_VIBECODE_OPENAI_API_KEY || LIBRARY_OPENAI_KEY || OPENAI_API_KEY;

  if (!apiKey) {
    return { success: true, data: createFallback() };
  }

  // Get the friendly name or title to search for more context
  const searchName = (document.metadata?.friendlyName as string) || document.shortTitle || document.title;

  const prompt = `You are a civic education AI helping citizens understand government actions.

I need you to create a comprehensive Citizen's Brief about this ${branchLabels[document.branch]}:

NAME/TITLE: "${searchName}"
Official Title: ${document.title}
Date: ${document.date}
Status: ${document.status}
Category: ${document.category}

Available Information:
${document.rawText.substring(0, 2000)}

IMPORTANT: Use your knowledge to provide accurate, detailed information about "${searchName}". If you know more about this specific bill/order/case than what's provided above, include that knowledge.

Generate TWO things:

1. CITIZEN'S BRIEF (5-7 sentences, comprehensive but readable):
   - What this ${branchLabels[document.branch].toLowerCase()} does in plain English
   - The specific provisions or key points
   - Who it affects and how (be specific about groups impacted)
   - Any controversy or debate surrounding it
   - Why it matters right now and what happens next
   - Keep it factual and non-partisan

2. REPRESENTATION GAP PROMPT:
   - A thought-provoking question about whether this represents the will of the people
   - Should encourage civic engagement without being partisan

Return as JSON:
{
  "citizensBrief": "Your 5-7 sentence brief here...",
  "representationGap": "Your thought-provoking question here?"
}`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'You are a non-partisan civic education expert with deep knowledge of US legislation, executive orders, and court cases. Use your full knowledge to provide accurate, comprehensive information. Be balanced, factual, and engaging. Always return valid JSON.',
          },
          { role: 'user', content: prompt },
        ],
        max_tokens: 800,
        temperature: 0.5,
      }),
    });

    if (!response.ok) {
      return { success: true, data: createFallback() };
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content ?? '';

    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]) as { citizensBrief: string; representationGap: string };

        return {
          success: true,
          data: {
            citizensBrief: parsed.citizensBrief,
            representationGap: parsed.representationGap,
            title: document.shortTitle,
            branch: document.branch,
            sourceUrl: document.sourceUrl,
            sourceId: document.id,
            category: document.category,
          },
        };
      }
    } catch {
      // JSON parse error - return fallback
    }

    return { success: true, data: createFallback() };
  } catch {
    return { success: true, data: createFallback() };
  }
}

/**
 * Quick preview - generates a shorter teaser for the slide-over preview
 */
export async function generateQuickPreview(
  document: GovernmentSearchResult
): Promise<{ success: boolean; data?: string; error?: string }> {
  // Use hardcoded library key first, then fall back to environment variable
  const apiKey = LIBRARY_OPENAI_KEY || OPENAI_API_KEY;

  // Create a meaningful fallback that's different from status
  const createFallback = (): string => {
    const branchLabels: Record<string, string> = {
      legislative: 'congressional bill',
      executive: 'executive order',
      judicial: 'court case',
    };

    const categoryLabels: Record<string, string> = {
      healthcare: 'healthcare policy',
      education: 'education policy',
      environment: 'environmental regulation',
      economy: 'economic policy',
      civil_rights: 'civil rights and liberties',
      defense: 'national security',
      immigration: 'immigration policy',
      technology: 'technology and communications',
      housing: 'housing policy',
      infrastructure: 'infrastructure and transportation',
    };

    const branchLabel = branchLabels[document.branch] ?? 'government action';
    const categoryLabel = categoryLabels[document.category] ?? document.category.replace('_', ' ');

    // Build a descriptive preview
    let preview = `This ${branchLabel} addresses ${categoryLabel}. `;

    if (document.metadata) {
      if (document.branch === 'legislative') {
        const congressNum = document.metadata.congressNumber as string ?? '';
        const chamber = document.metadata.chamber as string ?? '';
        if (congressNum || chamber) {
          preview += `It was introduced in the ${chamber || 'Congress'} as ${congressNum || 'a bill'}. `;
        }
      } else if (document.branch === 'executive') {
        const president = document.metadata.president as string ?? '';
        const eoNumber = document.metadata.eoNumber as string ?? '';
        if (president) {
          preview += `Signed by President ${president}. `;
        }
        if (eoNumber) {
          preview += `Document: ${eoNumber}. `;
        }
      } else if (document.branch === 'judicial') {
        const docketNumber = document.metadata.docketNumber as string ?? '';
        const court = document.metadata.court as string ?? 'Supreme Court';
        preview += `Decided by the ${court}. `;
        if (docketNumber) {
          preview += `Docket: ${docketNumber}. `;
        }
      }
    }

    preview += 'View the official source for full details.';

    return preview;
  };

  if (!apiKey) {
    // Return constructed fallback instead of raw text
    return { success: true, data: createFallback() };
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: 'You summarize government documents in 2-3 sentences for a quick preview. Be concise, factual, and focus on what the document does and who it affects. IMPORTANT: Do not just repeat the title or status - explain the practical impact and what citizens should know.',
          },
          {
            role: 'user',
            content: `Summarize this ${document.branch} document in 2-3 sentences. Focus on practical impact - what does it actually do and who does it affect?\n\nTitle: ${document.title}\nCategory: ${document.category}\nStatus: ${document.status}\n\nDetails: ${document.rawText.substring(0, 1500)}`,
          },
        ],
        max_tokens: 200,
        temperature: 0.5,
      }),
    });

    if (!response.ok) {
      // API error - return constructed fallback
      return { success: true, data: createFallback() };
    }

    const data = await response.json();
    const summary = data.choices?.[0]?.message?.content;

    // If AI returns something too short or empty, use fallback
    if (!summary || summary.length < 50) {
      return { success: true, data: createFallback() };
    }

    return { success: true, data: summary };
  } catch {
    return { success: true, data: createFallback() };
  }
}
