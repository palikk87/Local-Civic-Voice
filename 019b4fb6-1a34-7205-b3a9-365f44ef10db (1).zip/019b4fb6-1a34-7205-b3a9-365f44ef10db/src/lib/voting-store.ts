import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { FeedItem } from './types';
import { mockFeedItems } from './mock-data';

interface VotingState {
  userVotes: Record<string, 'yea' | 'nay'>;
  likedItems: Record<string, boolean>;
  feedItems: FeedItem[];
  castVote: (billId: string, vote: 'yea' | 'nay') => void;
  removeVote: (billId: string) => void;
  toggleLike: (itemId: string) => void;
  getUserVote: (billId: string) => 'yea' | 'nay' | null;
}

export const useVotingStore = create<VotingState>()(
  persist(
    (set, get) => ({
      userVotes: {},
      likedItems: {
        'feed-1': true,
        'feed-3': true,
        'feed-5': true,
      },
      feedItems: mockFeedItems,

      castVote: (billId: string, vote: 'yea' | 'nay') => {
        set((state) => ({
          userVotes: {
            ...state.userVotes,
            [billId]: vote,
          },
        }));
      },

      removeVote: (billId: string) => {
        set((state) => {
          const newVotes = { ...state.userVotes };
          delete newVotes[billId];
          return { userVotes: newVotes };
        });
      },

      toggleLike: (itemId: string) => {
        set((state) => ({
          likedItems: {
            ...state.likedItems,
            [itemId]: !state.likedItems[itemId],
          },
        }));
      },

      getUserVote: (billId: string) => {
        return get().userVotes[billId] ?? null;
      },
    }),
    {
      name: 'civic-voting-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        userVotes: state.userVotes,
        likedItems: state.likedItems,
      }),
    }
  )
);

// Selectors for optimal re-renders
export const selectUserVote = (billId: string) => (state: VotingState) =>
  state.userVotes[billId] ?? null;

export const selectIsLiked = (itemId: string) => (state: VotingState) =>
  state.likedItems[itemId] ?? false;
