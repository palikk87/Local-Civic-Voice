import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface AuthUser {
  id: string;
  email: string;
  username: string;
  displayName: string;
  avatar: string;
  bio: string;
  location: string;
  joinedDate: string;
  followers: number;
  following: number;
  votesCount: number;
}

interface AuthState {
  user: AuthUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  signUp: (email: string, password: string, username: string, displayName: string) => Promise<{ success: boolean; error?: string }>;
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signOut: () => void;
  updateProfile: (updates: Partial<AuthUser>) => void;
}

// Simple mock user database (in a real app, this would be a backend)
const mockUserDb: Map<string, { password: string; user: AuthUser }> = new Map();

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,

      signUp: async (email, password, username, displayName) => {
        set({ isLoading: true });

        // Simulate network delay
        await new Promise((resolve) => setTimeout(resolve, 800));

        // Check if email already exists
        if (mockUserDb.has(email)) {
          set({ isLoading: false });
          return { success: false, error: 'An account with this email already exists' };
        }

        // Create new user
        const newUser: AuthUser = {
          id: `user-${Date.now()}`,
          email,
          username,
          displayName,
          avatar: `https://api.dicebear.com/7.x/avataaars/png?seed=${username}`,
          bio: '',
          location: 'United States',
          joinedDate: new Date().toISOString().split('T')[0],
          followers: 0,
          following: 0,
          votesCount: 0,
        };

        mockUserDb.set(email, { password, user: newUser });

        set({ user: newUser, isAuthenticated: true, isLoading: false });
        return { success: true };
      },

      signIn: async (email, password) => {
        set({ isLoading: true });

        // Simulate network delay
        await new Promise((resolve) => setTimeout(resolve, 800));

        const userData = mockUserDb.get(email);

        if (!userData) {
          set({ isLoading: false });
          return { success: false, error: 'No account found with this email' };
        }

        if (userData.password !== password) {
          set({ isLoading: false });
          return { success: false, error: 'Incorrect password' };
        }

        set({ user: userData.user, isAuthenticated: true, isLoading: false });
        return { success: true };
      },

      signOut: () => {
        set({ user: null, isAuthenticated: false });
      },

      updateProfile: (updates) => {
        const currentUser = get().user;
        if (currentUser) {
          const updatedUser = { ...currentUser, ...updates };
          set({ user: updatedUser });

          // Update mock db
          const userData = mockUserDb.get(currentUser.email);
          if (userData) {
            mockUserDb.set(currentUser.email, { ...userData, user: updatedUser });
          }
        }
      },
    }),
    {
      name: 'civic-auth-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
);
